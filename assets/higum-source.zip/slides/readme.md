# HiGUM — LARS 2026 animated presentation

Manim Slides presentation of **HiGUM: A Hierarchical Gaussian Model for Cooperative Multi-UAV Smoke Monitoring**, by David Saldaña, Yunyao Li, and Diego Patiño. The source paper is [`../conference_101719.tex`](../conference_101719.tex).

The presentation draws its geometry and animations in Manim. It does not display screenshots, PDFs, or PNGs of the paper's figures.

The deck covers 18 topics, with presenter-controlled animation steps: motivation, voxel and octree related work, the end-to-end pipeline, the hierarchy and node statistics, recursive binary GMM fitting, Figures 1–3, waypoint allocation and tours, UAV dynamics, nonlinear MPC, the two Figure 4 flight cases (16 and 32 waypoints), computational scaling, conclusions, and the Gaussian “Thank you” demonstration.

## Ready-to-open presentation

Open [`higum.html`](higum.html) in a browser. This included 1080p presentation embeds all 68 presenter-controlled animation steps and the Reveal.js runtime, so it works offline without installing Python. Left-click the slide canvas or use the arrow keys to advance through the animations. On either fleet trajectory animation, clicking while it is running finishes the path and holds the completed trajectory; click again to advance. The browser tab is titled HiGUM. Use **F** for full screen. Each build waits for presenter input. The source and installation steps below let you edit and re-render it.

A continuous video is also available at [`media/videos/higum/1080p30/HiGUM.mp4`](media/videos/higum/1080p30/HiGUM.mp4). The HTML and native presenter pause between steps; the continuous video plays the animations without time for narration.

## Install

Use Python **3.11** and an isolated environment. Run the commands below from this `slides` directory.

On macOS, install the native rendering dependencies with Homebrew:

```bash
brew install cairo pango pkg-config ffmpeg
```

Install a TeX distribution that provides `latex` and `dvisvgm`, such as [MacTeX](https://www.tug.org/mactex/), for the animated mathematical expressions. Make sure both executables are on `PATH` (normally `/Library/TeX/texbin` on macOS).

On Ubuntu/Debian, the equivalent dependencies are:

```bash
sudo apt-get install build-essential python3-dev python3-venv libcairo2-dev libpango1.0-dev pkg-config ffmpeg texlive-latex-extra texlive-fonts-extra dvisvgm
```

Then install the pinned Python packages:

```bash
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

The requirements include PySide6 for the native presentation window. Rendering and HTML export do not need a graphical display. If using Windows, follow the [Manim installation guide](https://docs.manim.community/en/stable/installation.html) for native prerequisites, then use `.venv\Scripts\Activate.ps1` to activate the environment in PowerShell.

## Render and present

Render a quick 480p / 15 fps preview:

```bash
manim-slides render -ql higum.py HiGUM
```

Render the final presentation at 1080p / 30 fps:

```bash
manim-slides render --quality h --fps 30 higum.py HiGUM
```

Then present the rendered deck:

```bash
manim-slides present HiGUM
```

Use **Right / Left** to advance or go back, **Space** to pause/resume, **R** to replay the current animation, **F** for full screen, and **Q** to quit. Advancing moves through animation fragments; a conceptual slide can contain several fragments.

Rendering writes videos to `media/` and the presentation manifest/fragments to the generated `slides/` subdirectory. Keep that generated subdirectory: `manim-slides present` and `convert` read it. Re-render after changing the source or numeric assets.

## Slower motion and click controls

All animation durations use a default multiplier of **1.6**. Figure 4 flights now play over **28.8 seconds** per case, compared with 12 seconds in the first version. To slow the deck further, set `HIGUM_PACE` before rendering:

```bash
HIGUM_PACE=2.0 manim-slides render --quality h --fps 30 higum.py HiGUM
```

The overview and WRF-FIRE hierarchy are topics **5 and 10**. Topic **12** covers UAV dynamics, and topic **13** covers NMPC. Builds wait for a click, including each discrete dynamics step, each NMPC loop step, and each Gaussian resolution on the closing slide. Native presentation uses Right/Left; the included HTML additionally supports left-clicking the slide canvas.

## Export animated HTML

After rendering, export the offline single-file browser presentation, including mouse-click navigation:

```bash
python util/export_html.py
```

This creates `higum.html`. Export requires internet to download and embed the Reveal.js runtime. The exported file contains its videos, scripts, and styles and can then be opened offline. To choose a different filename:

```bash
python util/export_html.py my-presentation.html
```

If runtime downloads are unavailable, export with an online runtime instead:

```bash
python util/export_html.py --online-runtime
```

That fallback embeds the animations but needs internet when viewing. Direct `manim-slides convert` also works, but the wrapper preserves the custom canvas-click controls.

## Figures recreated as animations

| Paper figure | Presentation treatment |
| --- | --- |
| Figure 1 | Generate the three-source synthetic plume, fit the root Gaussian, and refine the hierarchy into 4 and 16 ellipsoids. |
| Figure 2 | Animate recursive binary GMM partitioning of the curved synthetic plume through 2, 4, and 8 components. |
| Figure 3 | Reveal the WRF-FIRE point cloud and transform it into 4- and 32-component Gaussian representations. |
| Figure 4 | Animate UAVs following the computed nonlinear MPC trajectories, with their waypoint cycles, for the 16- and 32-waypoint fleet/resolution cases. |

## Related work: voxels and octrees

Slides **3 and 4**, immediately after the forest-fire motivation, animate the **same 900 samples from the three-source synthetic plume** used by the Gaussian representation. The first maps samples to equal-size voxels and refines the uniform cell width. The second subdivides the domain into octants and shows an adaptive octree with leaves of different sizes. Each displayed cell summarizes the mean concentration of its assigned samples. Empty cells are unobserved; these data contain no sensing rays or free-space evidence.

The illustrations explain spatial representations used in robotics, rather than reproduce the complete algorithms of either related work:

- [Voxblox, Oleynikova et al., IROS 2017](https://voxblox.readthedocs.io/en/latest/): incremental TSDF/ESDF voxel mapping for MAV planning, using voxel blocks and hashing.
- [OctoMap, Hornung et al., Autonomous Robots 2013](https://octomap.github.io/): probabilistic occupancy mapping with octrees and multiple spatial resolutions.

The uniform-grid stages contain **57 and 195 nonempty cells** at 8³ and 16³ resolutions. The adaptive octree refines cells with more than 24 samples, to depth 4, and finishes with **122 leaves** spanning depths 1–4. These values are recalculated from the original data. To validate sample coverage and print the derived geometry statistics:

```bash
python util/spatial_representations.py
```

The smoke-cell demonstration does not estimate TSDF/ESDF distances or probabilistic occupancy. HiGUM instead fits data-aligned Gaussian ellipsoids in a binary hierarchy and uses their centroids as planning targets. Cell and leaf counts are computed from the demonstration, not memory or accuracy benchmarks of the cited systems.

## New motivation and closing slides

The title slide includes the original [Lehigh University logo](https://www.lehigh.edu/LTS/communication/logos/) and [UT Arlington logo](https://www.uta.edu/), using official transparent artwork with white lettering for the dark background. The images retain their original proportions; source and download details are in `assets/lehigh_logo_source.json` and `assets/uta_logo_source.json`.

Slide 2 uses a real [aerial photograph of the 2013 Alder Fire in Yellowstone](https://commons.wikimedia.org/wiki/File:Wildfire_(14503287131).jpg), photographed by Mike Lewelling/NPS and marked public domain. It is a different image from the supplied stock reference. Full source and license details are in `assets/forest_smoke_source.json`.

Slide 12 includes a [NASA photograph of the small Black Swift S2 environmental-monitoring UAV](https://www.nasa.gov/image-detail/crater-052025-loiacono-3978/), credited to NASA/Milan Loiacono. It is used for airborne imaging and atmospheric sampling in the [CRATER mission](https://espo.nasa.gov/crater). Attribution and crop information are in `assets/monitoring_uav_source.json`; the photo illustrates a suitable platform category, not the aircraft used in the paper simulation. Slide 6 uses larger, brighter points and retains their visibility during Gaussian refinement. Slide 10 uses bright cyan sample-location markers, including during ellipsoid refinement; ellipsoid colors still encode mean concentration on a logarithmic scale.

Slide **12** presents the reduced planar UAV dynamics beside six exact explicit-Euler updates. The animation resolves each displacement into Δx = Δt v₀ cos ψₜ and Δy = Δt v₀ sin ψₜ, while simultaneously rotating the UAV by Δψ = Δt (v₀/L) tan δₜ. All three increments use the state at time t and share one animation clock. Illustrative values are Δt = 1 s, v₀ = 10 m/s, L = 10 m, and steering commands 0, +0.35, +0.35, 0, −0.35, −0.35 rad. These schematic updates are separate from the stored NMPC flight experiments.

Slide **13** presents the NMPC cost and constraints, followed by the click-controlled feedback loop: measure the state, optimize the horizon, apply the first input, and measure again. The paper's objective is shown; presenter notes explain the additional steering-smoothness penalties in the supplied implementation. The Figure 4 cases now occupy slides **14–16**.

The closing slide samples **65,536 points** inside the “Thank you” letter strokes, then applies the original recursive binary full-covariance GMM function to show **8, 16, 32, 64, 128, 256, 512, and 1,024 Gaussians**. This is a planar illustration of the method, rather than smoke data. Validate or regenerate this separate asset with:

```bash
python util/prepare_thank_you.py
python util/prepare_thank_you.py --force
```

## Figure 4 target audit

The purple UAV's route, trajectory, and color are correctly paired. Its original MPC trajectory passes close to another UAV's node while pursuing its own assigned target. The animation now shows the active target ring and connector, and fills a waypoint only when its owner accepts it in route order. The original 3 km waypoint tolerance is unchanged. Run the audit with:

```bash
python util/audit_trajectories.py
```

The original-path audit is saved in `assets/trajectory_audit.json`. Original MPC arrays remain in `assets/higum_data.npz`. Slide 14 uses the separately saved replanned demonstration described below.

## Slide 14 MPC improvement

Slide 14 now replays a **regenerated level-4 experiment**, clearly labeled on the slide. The original controller optimizes against one stationary active waypoint for its whole horizon. Increasing that horizon can continue to reward circling around the same target. The replacement tracks reference points along the assigned route, emphasizes near-term tracking, and warm-starts each solve from the preceding solution.

With the original stationary-target cost, the tested aggregate lengths were **143 km at 100 steps**, **157 km at 150 steps**, and **158 km at 200 steps**. All cases completed their ordered targets, so a longer horizon alone did not improve this example.

The selected route-aware controller uses **20 steps**. Its three path lengths are **35, 32, and 29 km**, versus **57, 37, and 49 km** in the original 100-step implementation: **96 km total versus 143 km**, a **32.9% reduction**. All 16 assigned centroids are still accepted in the original order and each UAV returns to the depot tolerance. The allocation, waypoint order, speed, steering bound, turning-length parameter, and 3 km acceptance disks are unchanged. Every stored state was checked against the model and every applied-control solve converged.

This is a presentation control experiment, not a replacement claim for the paper's original result or a globally optimal tour. Longer-horizon comparisons and complete parameters are in `assets/mpc_comparison.json`; the original paper code and numeric arrays are preserved. Validate or rebuild the selected candidate with:

```bash
python util/tune_mpc.py
python util/tune_mpc.py --rebuild
```

`assets/improved_plans.npz` contains the separate level-4 routes, states, controls, and acceptance events. Other fleet cases still use the paper's original trajectories.

## Numeric data and reproducibility

`assets/higum_data.npz` contains numeric point locations, concentrations, Gaussian parameters, waypoint routes, and MPC trajectories. `assets/metadata.json` records parameters, source-file hashes, and trajectory checks. The deck reads these arrays; it does not read the paper's figure files.

The included arrays are enough to render the deck. Validate them with:

```bash
python util/prepare_data.py
```

Recompute them using the original methods in `../code`:

```bash
python util/prepare_data.py --force
```

Rebuilding needs `../code/fire_smoke_data.npy` and can take several minutes because it refits Gaussian hierarchies, solves exact waypoint tours, and runs CasADi/IPOPT nonlinear MPC for every UAV. Fixed seeds reproduce the data and partitions; numerical solver results can vary slightly by platform. The original fleet cases are generated by the paper's planner; slide 14 loads the separate route-aware controller result. Playback compresses the model duration for presentation; all UAVs in a case share one integration clock, so shorter flights finish earlier. Waypoint acceptance uses the original planner's 3 km tolerance.

The displayed MPC cost follows the paper's equation. The original planner used to generate the animated paths also penalizes changes in steering, as noted in the presenter notes.

The paper models a static plume and constant-altitude flight. Collision avoidance, communication constraints, and time-varying plume tracking are future work, as reflected in the concluding slide. The runtime topic explains the published benchmark protocol; it does not introduce new timing measurements.

## Files

- `higum.py`: the `HiGUM` Manim Slides scene.
- `higum.html`: ready-to-open offline presentation.
- `manim.cfg`: default rendering configuration.
- `requirements.txt`: tested Python dependencies.
- `assets/`: numeric animation inputs and provenance.
- `media/` and `slides/`: generated videos, render cache, and native presenter files.
- `util/spatial_representations.py`: voxel and octree related-work animation helpers.
- `util/control_slides.py`: UAV dynamics, exact Euler state updates, and the NMPC feedback loop.
- `util/thank_you.py`: closing animation helper.
- `util/prepare_data.py` and `util/prepare_thank_you.py`: asset validation and regeneration.
- `util/audit_trajectories.py`: validates original waypoint ownership and target acceptance.
- `util/tune_mpc.py`: validates/rebuilds the route-aware level-4 demonstration and compares horizons.
- `util/export_html.py`: offline HTML export with mouse-click navigation.
- `util/review/`: review timestamps and archived preview files. New renders write `review_states.json` here.

Run the commands above from `slides/`. Utility scripts resolve their default asset and output paths relative to the slide directory, even when invoked from another working directory. Keep `util/` alongside `higum.py`, which imports its animation helpers.

See the official [Manim Slides CLI reference](https://manim-slides.eertmans.be/latest/reference/cli.html) and [sharing guide](https://manim-slides.eertmans.be/latest/reference/sharing.html) for presenter and export options.
