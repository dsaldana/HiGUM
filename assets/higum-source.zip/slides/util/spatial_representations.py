"""Two click-controlled related-work builds, using the exact Figure 1 samples.

Voxblox and OctoMap motivate the data structures. This is a scalar-smoke
illustration, not a reproduction of either mapping system: occupied here means
at least one measured sample; a cell color is its samples' arithmetic mean
PM2.5. No free space, occupancy probabilities, ray tracing, TSDF or ESDF is
inferred. Empty octree children are omitted from the stored representation.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import json
from pathlib import Path

import numpy as np
from manim import *
from manimpango import list_fonts

INK = "#EDF2F7"
MUTED = "#9CADC2"
CYAN = "#62D9E8"
HEAT = ["#4B427C", "#B65B94", "#F59067", "#FFD58A"]
FONT = next((f for f in ("Arial", "DejaVu Sans", "Liberation Sans") if f in list_fonts()), "sans-serif")
VERTEX_BITS = np.array([[i & 1, (i >> 1) & 1, (i >> 2) & 1] for i in range(8)])
VISIBLE_FACES = [[0, 2, 6, 4], [0, 1, 5, 4], [4, 5, 7, 6]]
EDGES = [(i, i ^ (1 << axis)) for i in range(8) for axis in range(3) if not i & (1 << axis)]


@dataclass
class Cell:
    lower: np.ndarray
    side: float
    ids: np.ndarray
    depth: int
    code: int = -1
    children: list = field(default_factory=list)

    @property
    def vertices(self):
        return self.lower + VERTEX_BITS * self.side


class _Projection:
    """One affine oblique projection for all samples and all cube vertices."""
    def __init__(self, root):
        self.center = root.lower + root.side / 2
        # A shallow oblique view keeps the full cubic domain on screen without
        # reducing the narrow smoke cloud to a small patch. No cell geometry is
        # distorted independently: this same affine map acts on every vertex.
        self.matrix = np.array([[0.78, -0.62, 0.0], [0.12, 0.16, 0.47]])
        flat = (root.vertices - self.center) @ self.matrix.T
        self.scale = min(8.4 / np.ptp(flat[:, 0]), 4.5 / np.ptp(flat[:, 1]))
        self.offset = np.array([-1.8, -0.1, 0.0])

    def __call__(self, points):
        flat = (np.asarray(points) - self.center) @ self.matrix.T * self.scale
        return np.concatenate([flat, np.zeros((*flat.shape[:-1], 1))], axis=-1) + self.offset


def _uniform(points, lower, side, divisions):
    width = side / divisions
    indices = np.floor((points - lower) / width).astype(int)
    # The padded domain strictly contains the data, avoiding boundary clipping.
    if np.any(indices < 0) or np.any(indices >= divisions):
        raise ValueError("Samples extend outside the shared cube domain")
    occupied, assignment = np.unique(indices, axis=0, return_inverse=True)
    return [Cell(lower + index * width, width, np.flatnonzero(assignment == j),
                 int(np.log2(divisions))) for j, index in enumerate(occupied)]


def _octree(points, root, max_samples=24, max_depth=4):
    def split(cell):
        if len(cell.ids) <= max_samples or cell.depth == max_depth:
            return
        half = cell.side / 2
        codes = ((points[cell.ids] >= cell.lower + half) * np.array([1, 2, 4])).sum(axis=1)
        for code in range(8):
            ids = cell.ids[codes == code]
            if not len(ids):
                continue
            child = Cell(cell.lower + VERTEX_BITS[code] * half, half, ids,
                         cell.depth + 1, code=code)
            cell.children.append(child)
            split(child)
    split(root)
    return root


def _leaves_at(cell, depth):
    if not cell.children or cell.depth >= depth:
        return [cell]
    return [leaf for child in cell.children for leaf in _leaves_at(child, depth)]


def build_representation_data(data):
    """Derive fixed grids and a sparse eight-way tree directly from Fig. 1."""
    points = np.asarray(data["fig1_points"])
    concentration = np.asarray(data["fig1_concentration"])
    center = (points.min(axis=0) + points.max(axis=0)) / 2
    side = float(np.ptp(points, axis=0).max() * 1.04)
    lower = center - side / 2
    root = _octree(points, Cell(lower, side, np.arange(len(points)), 0))
    return {"points": points, "concentration": concentration, "root": root,
            "voxels": {n: _uniform(points, lower, side, n) for n in (8, 16)},
            "octree": {depth: _leaves_at(root, depth) for depth in (1, 3, 4)}}


def validate_representation_data(rep):
    """Check exact sample coverage, cube containment and true eight-way splits."""
    points, root = rep["points"], rep["root"]
    expected = np.arange(len(points))

    def validate_partition(cells):
        assigned = np.concatenate([c.ids for c in cells])
        assert np.array_equal(np.sort(assigned), expected), "Samples must occur exactly once"
        for cell in cells:
            assert len(cell.ids) > 0
            assert np.all(points[cell.ids] >= cell.lower - 1e-10)
            assert np.all(points[cell.ids] <= cell.lower + cell.side + 1e-10)

    for cells in [*rep["voxels"].values(), *rep["octree"].values()]:
        validate_partition(cells)

    def validate_node(node):
        if not node.children:
            assert len(node.ids) <= 24 or node.depth == 4
            return
        assert len(node.children) <= 8
        assert len({c.code for c in node.children}) == len(node.children)
        assert np.array_equal(np.sort(np.concatenate([c.ids for c in node.children])), np.sort(node.ids))
        for child in node.children:
            assert child.depth == node.depth + 1
            assert np.isclose(child.side, node.side / 2)
            assert np.allclose(child.lower, node.lower + VERTEX_BITS[child.code] * node.side / 2)
            assert np.all(child.lower >= node.lower - 1e-10)
            assert np.all(child.lower + child.side <= node.lower + node.side + 1e-10)
            validate_node(child)
    validate_node(root)
    return True


def get_metadata(data):
    rep = build_representation_data(data)
    validate_representation_data(rep)
    return {"sample_count": len(rep["points"]), "domain_cube_side": rep["root"].side,
            "voxel_occupied_counts": {str(n): len(cells) for n, cells in rep["voxels"].items()},
            "voxel_widths": {str(n): rep["root"].side / n for n in rep["voxels"]},
            "octree_leaf_counts": {str(d): len(cells) for d, cells in rep["octree"].items()},
            "octree_final_depth_counts": {str(d): sum(c.depth == d for c in rep["octree"][4])
                                           for d in range(1, 5)},
            "octree_max_samples": 24, "octree_max_depth": 4,
            "description": "Exact Figure 1 samples; mean measured PM2.5 per nonempty cell; no free-space inference."}


def _label(text, size=24, color=INK):
    return Text(text, font=FONT, font_size=size, color=color)


def _color(value, values):
    t = float(np.clip((value - values.min()) / np.ptp(values), 0, 1))
    k = min(int(t * 3), 2)
    color = interpolate_color(ManimColor(HEAT[k]), ManimColor(HEAT[k + 1]), t * 3 - k)
    return interpolate_color(color, ManimColor(INK), 0.22)


def _wire(cell, project, color=MUTED, opacity=.4, width=.8):
    vertices = project(cell.vertices)
    return VGroup(*[Line(vertices[i], vertices[j], color=color,
                        stroke_opacity=opacity, stroke_width=width) for i, j in EDGES])


def _cells(cells, project, values, opacity=.33):
    # Painter order agrees with the normal of the projection's screen plane.
    view_direction = np.cross(project.matrix[0], project.matrix[1])
    order = sorted(cells, key=lambda c: (c.lower + c.side / 2) @ view_direction)
    group = VGroup()
    for cell in order:
        color = _color(values[cell.ids].mean(), values)
        vertices = project(cell.vertices)
        faces = VGroup(*[Polygon(*vertices[indices], fill_color=color,
                                fill_opacity=opacity * shade, stroke_color=color,
                                stroke_opacity=.85, stroke_width=.65)
                         for indices, shade in zip(VISIBLE_FACES, [.62, .82, 1.0])])
        group.add(faces)
    return group


def _cloud(rep, project):
    return VGroup(*[Dot(project(p), radius=.024, color=_color(c, rep["concentration"]),
                       fill_opacity=1, stroke_width=0)
                   for p, c in zip(rep["points"], rep["concentration"])])


def _caption(text):
    result = _label(text, 20, CYAN)
    if result.width > 8.7:
        result.scale_to_fit_width(8.7)
    return result.move_to([-1.8, -2.65, 0])


def _paragraph(scene, lines, top=1.9, size=23):
    return scene.paragraph(lines, x=4.75, top=top, size=size, width=3.7)


def _key(rep):
    bars = VGroup(*[Line([3.22 + j*.077, -1.87, 0], [3.22 + (j+1)*.077, -1.87, 0],
                        stroke_width=11, color=_color(rep["concentration"].min() +
                            j / 39 * np.ptp(rep["concentration"]), rep["concentration"])) for j in range(40)])
    return VGroup(bars,
                  _label("Cell mean PM₂.₅", 18, MUTED).move_to([4.72, -1.44, 0]),
                  _label("low", 15, MUTED).move_to([3.35, -2.14, 0]),
                  _label("high", 15, MUTED).move_to([6.15, -2.14, 0]))


def spatial_representations(scene):
    """Insert immediately after motivation; all builds advance on a click."""
    rep = build_representation_data(scene.data)
    validate_representation_data(rep)
    root, values = rep["root"], rep["concentration"]
    project = _Projection(root)

    scene.page("Related work: voxel representation", "Oleynikova et al., Voxblox, IROS 2017  /  Scalar-smoke illustration")
    cloud = _cloud(rep, project)
    domain = _wire(root, project, opacity=.22)
    caption = _caption("The same 900 synthetic three-source samples")
    info = _paragraph(scene, ["A uniform 3-D grid", "One fixed cell width", "", "Keep cells containing", "input samples."])
    triad = scene.triad(origin=(-5.8, -2.28, 0))
    scene.play(FadeIn(cloud), Create(domain), FadeIn(triad), FadeIn(caption), FadeIn(info), run_time=1.8)
    scene.pause("Related work: voxel representation. The exact 900 Figure 1 samples are shown. "
                "Voxblox is a volumetric distance-field mapping system using dynamically allocated hashed voxel blocks: "
                "https://voxblox.readthedocs.io/en/latest/ . "
                "This is a scalar-smoke illustration of the fixed-resolution grid data structure, not a Voxblox reproduction. "
                "The finite enclosing cube is an illustration choice, not a claim that Voxblox stores a dense fixed-extent grid. "
                "No TSDF/ESDF or free space is inferred. Click to bin the samples.")

    current = None
    for n in (8, 16):
        new = _cells(rep["voxels"][n], project, values)
        new_caption = _caption(f"{len(rep['voxels'][n])} nonempty cells  ·  width = L/{n}  ·  {n}³ grid")
        if current is None:
            scene.play(cloud.animate.set_opacity(.2), FadeIn(new),
                       Transform(caption, new_caption), FadeIn(_key(rep)), run_time=2.1)
        else:
            new_info = _paragraph(scene, ["Halve the cell width", "Resolve finer structure", "", "Finer uniform grids", "store more cells."])
            scene.play(FadeOut(current), FadeIn(new), Transform(caption, new_caption),
                       Transform(info, new_info), run_time=2.1)
        current = new
        scene.pause(f"Uniform voxel grid: {n} cells per axis, {len(rep['voxels'][n])} nonempty cells. "
                    f"Width is domain side L/{n} = {root.side/n:.3f} in source coordinates. "
                    "Each of the 900 samples belongs to exactly one displayed cell; color is the arithmetic mean measured PM2.5. "
                    "Unstored cells are unobserved here, not inferred free space. "
                    + ("Click to halve the common cell width." if n == 8 else "Click to compare an adaptive octree."))

    scene.page("Related work: octree representation", "Hornung et al., OctoMap, Autonomous Robots 2013  /  Scalar-smoke illustration")
    cloud = _cloud(rep, project)
    domain = _wire(root, project, color=CYAN, opacity=.65, width=1.2)
    caption = _caption("One cubic root contains the same 900 samples")
    info = _paragraph(scene, ["Axis-aligned cubes", "Eight children per split", "", "Refine cells with", "more than 24 samples.", "Stop at depth 4."], size=22)
    scene.play(FadeIn(cloud), Create(domain), FadeIn(scene.triad(origin=(-5.8, -2.28, 0))),
               FadeIn(caption), FadeIn(info), run_time=1.8)
    scene.pause("Related work: octree. A cube encloses the same 900 Figure 1 samples. "
                "OctoMap is a probabilistic occupancy mapping system: https://octomap.github.io/ . "
                "This illustration uses only its axis-aligned eight-way spatial subdivision, not occupancy probabilities, "
                "ray integration or inferred free space. Click to split the root into its eight equal child cubes.")

    current = None
    for depth in (1, 3, 4):
        leaves = rep["octree"][depth]
        new = _cells(leaves, project, values, opacity=.24 if depth == 1 else .33)
        if depth == 1:
            new_caption = _caption("First split: 8 equal child cubes")
            scene.play(cloud.animate.set_opacity(.28), FadeIn(new), FadeIn(_key(rep)),
                       Transform(caption, new_caption), domain.animate.set_opacity(.16), run_time=2.2)
        else:
            new_caption = _caption(f"{len(leaves)} stored leaves  ·  adaptive depths 1–{depth}")
            if depth == 3:
                new_info = _paragraph(scene, ["Refine where samples", "are more numerous.", "", "Keep coarse leaves", "in sparse regions.", "Omit empty children."], size=22)
            else:
                new_info = _paragraph(scene, ["Octree: 8-way cubes", "Axis-aligned partitions", "", "HiGUM: binary splits", "Data-driven ellipsoids"], size=22)
            scene.play(FadeOut(current), FadeIn(new), Transform(caption, new_caption),
                       Transform(info, new_info), run_time=2.4)
        current = new
        depth_counts = {d: sum(c.depth == d for c in leaves) for d in sorted({c.depth for c in leaves})}
        scene.pause(f"Adaptive octree at maximum displayed depth {depth}: {len(leaves)} nonempty leaf cubes; "
                    f"leaf counts by depth: {depth_counts}. Every split divides one parent into eight equal spatial octants; "
                    "only children containing measured samples are stored. Each sample belongs to exactly one displayed leaf. "
                    "Colors are leaf mean PM2.5, not occupancy probabilities. "
                    + ("Click to refine dense cells further." if depth < 4 else
                       "Compare the adaptive axis-aligned cubes with HiGUM's subsequent data-driven binary Gaussian hierarchy. "
                       "These are qualitative representation differences; no runtime or storage benchmark is claimed."))


if __name__ == "__main__":
    with np.load(Path(__file__).resolve().parents[1] / "assets" / "higum_data.npz", allow_pickle=False) as data:
        print(json.dumps(get_metadata(data), indent=2))
