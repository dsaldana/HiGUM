"""Presentation helpers, asset preparation, export, and validation tools."""
