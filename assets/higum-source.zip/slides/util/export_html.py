"""Export an offline, single-file deck with left-click advancement.

Run from slides/ after rendering: python util/export_html.py
Reveal.js runtime downloads need internet on export; viewing is fully offline.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import re
import shutil
import subprocess
import sys

CLICK_SCRIPT = r"""
<script id="higum-click-navigation">
  // Finish a running fleet animation before navigating away from its final path.
  function higumAdvance() {
    if (typeof Reveal === 'undefined' || Reveal.isOverview() || Reveal.isPaused()) return;
    const slide = Reveal.getCurrentSlide();
    const finalTrajectory = slide.querySelector('.notes')?.textContent.includes('Every colored node has now been accepted');
    const video = slide.slideBackgroundContentElement?.querySelector('video');
    if (finalTrajectory && video && !video.ended) {
      if (!Number.isFinite(video.duration) || video.duration <= 0) return;
      if (video.currentTime < video.duration - 0.1) {
        video.pause();
        video.currentTime = Math.max(0, video.duration - 0.04);
        return; // Hold the completed trajectory until another deliberate click.
      }
    }
    Reveal.next();
  }
  Reveal.configure({autoSlide: false});
  Reveal.addKeyBinding({keyCode: 39, key: 'RIGHT', description: 'Finish trajectory / next slide'}, higumAdvance);
  document.addEventListener('click', function (event) {
    if (!event.target.closest('.navigate-right, .navigate-down')) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    higumAdvance();
  }, true);
  document.addEventListener('click', function (event) {
    if (event.button !== 0 || event.defaultPrevented) return;
    if (event.target.closest('a, button, input, textarea, select, .controls, .progress, .speaker-notes')) return;
    higumAdvance();
  });
</script>
"""


def customize(content):
    content = re.sub(r'<title>.*?</title>', '<title>HiGUM</title>', content, count=1, flags=re.S)
    content = re.sub(r'<script id="higum-click-navigation">.*?</script>', '', content, flags=re.S)
    before, closing, after = content.rpartition('</body>')
    if not closing:
        raise RuntimeError('Export has no closing body tag')
    return before + CLICK_SCRIPT + closing + after


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", nargs="?", default="higum.html")
    parser.add_argument("--online-runtime", action="store_true", help="use CDN runtime instead of downloading and embedding it")
    args = parser.parse_args()
    here = Path(__file__).resolve().parents[1]
    executable = Path(sys.executable).with_name("manim-slides")
    if not executable.is_file():
        found = shutil.which("manim-slides")
        if not found:
            parser.error("Activate the environment containing manim-slides first")
        executable = Path(found)
    output = Path(args.output)
    if not output.is_absolute():
        output = here / output
    command = [str(executable), "convert", "--one-file"]
    if not args.online_runtime:
        command += ["--offline", "--disable-revealjs-cache"]
    command += ["HiGUM", str(output)]
    subprocess.run(command, cwd=here, check=True)
    content = output.read_text()
    output.write_text(customize(content))
    print(f"Exported click-controlled presentation: {output}")


if __name__ == "__main__":
    main()
