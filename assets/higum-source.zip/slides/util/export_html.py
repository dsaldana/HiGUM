"""Export an offline, single-file deck with left-click advancement.

Run from slides/ after rendering: python util/export_html.py
Reveal.js runtime downloads need internet on export; viewing is fully offline.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import shutil
import subprocess
import sys

CLICK_SCRIPT = r"""
<script id="higum-click-navigation">
  // Deliberate presenter input advances every animation build.
  document.addEventListener('click', function (event) {
    if (event.button !== 0 || event.defaultPrevented) return;
    if (event.target.closest('a, button, input, textarea, select, .controls, .progress, .speaker-notes')) return;
    if (typeof Reveal !== 'undefined' && !Reveal.isOverview() && !Reveal.isPaused()) {
      Reveal.next();
    }
  });
</script>
"""


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", nargs="?", default="higum.html")
    parser.add_argument("--online-runtime", action="store_true", help="use CDN runtime instead of downloading and embedding it")
    args = parser.parse_args()
    here = Path(__file__).resolve().parents[1]
    executable = Path(sys.executable).with_name("manim-slides")
    if not executable.is_file():
        found = shutil.which("manim-slides")
        if not found:
            parser.error("Activate the environment containing manim-slides first")
        executable = Path(found)
    output = Path(args.output)
    if not output.is_absolute():
        output = here / output
    command = [str(executable), "convert", "--one-file"]
    if not args.online_runtime:
        command += ["--offline", "--disable-revealjs-cache"]
    command += ["HiGUM", str(output)]
    subprocess.run(command, cwd=here, check=True)
    content = output.read_text()
    before, closing, after = content.rpartition("</body>")
    if not closing:
        raise RuntimeError("Export has no closing body tag")
    output.write_text(before + CLICK_SCRIPT + closing + after)
    print(f"Exported click-controlled presentation: {output}")


if __name__ == "__main__":
    main()
