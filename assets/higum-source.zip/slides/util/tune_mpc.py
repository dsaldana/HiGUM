#!/usr/bin/env python3
"""Validate or rebuild the presentation's route-aware MPC experiment.

The published data and original planner are never changed. By default this
script audits the cached level-4 experiment. ``--rebuild`` reruns its nonlinear
MPC. ``--compare-horizons`` additionally reruns the original, active-target-only
controller with longer horizons; that optional comparison takes several minutes.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import time

import numpy as np

HERE = Path(__file__).resolve().parents[1]
ASSETS = HERE / "assets"
ORIGINAL = ASSETS / "higum_data.npz"
OUTPUT = ASSETS / "improved_plans.npz"
REPORT = ASSETS / "mpc_comparison.json"
HORIZON = 20
DT = 0.1
SPEED = 10.0
TURNING_LENGTH = 5.0
DELTA_MAX = np.deg2rad(60.0)
TOLERANCE = 3.0


def make_solver(horizon: int):
    """Track the upcoming tour rather than orbiting one stationary target.

    A constant-speed aircraft cannot stop at a waypoint. The original cost
    repeats that same waypoint throughout its 100-step horizon, which can favor
    loops. Here, reference positions advance along the remaining assigned tour.
    A temporal discount emphasizes attainable near-term motion; the original
    steering-effort, steering-change, and second-difference penalties remain.
    """
    import casadi as ca

    x = ca.SX.sym("X", 3, horizon + 1)
    u = ca.SX.sym("U", 1, horizon)
    p = ca.SX.sym("P", 4 + 2 * horizon)
    constraints = [x[:, 0] - p[:3]]
    cost = 0
    for k in range(horizon):
        delta, theta = u[0, k], x[2, k]
        dynamics = ca.vertcat(
            SPEED * ca.cos(theta), SPEED * ca.sin(theta),
            SPEED / TURNING_LENGTH * ca.tan(delta),
        )
        constraints.append(x[:, k + 1] - x[:, k] - DT * dynamics)
        error = x[:2, k] - p[4 + 2 * k:6 + 2 * k]
        cost += np.exp(-k / 15) * (5 * ca.dot(error, error) + .05 * delta**2)
        du = delta - (p[3] if k == 0 else u[0, k - 1])
        cost += (12 if k == 0 else 15) * du**2
        if k >= 2:
            cost += 6 * (delta - 2 * u[0, k - 1] + u[0, k - 2])**2
    return ca.nlpsol(
        "route_aware_mpc", "ipopt",
        {"x": ca.vertcat(ca.vec(x), ca.vec(u)), "p": p,
         "g": ca.vertcat(*constraints), "f": cost},
        {"ipopt.print_level": 0, "print_time": 0, "ipopt.max_iter": 500},
    )


def references(state: np.ndarray, remaining_route: np.ndarray, horizon: int):
    """Sample the remaining polyline at the constant-speed prediction interval.

    Beyond the depot, continue along its final approach direction. This is only
    a predictive reference: the simulated vehicle stops being displayed once
    the depot acceptance disk is reached. It avoids asking a fixed-speed model
    to remain stationary at the final point during its prediction horizon.
    """
    polyline = np.vstack([state[:2], remaining_route])
    direction = polyline[-1] - polyline[-2]
    direction /= max(np.linalg.norm(direction), 1e-9)
    polyline = np.vstack([polyline, polyline[-1] + direction * horizon * SPEED * DT])
    lengths = np.linalg.norm(np.diff(polyline, axis=0), axis=1)
    polyline = polyline[np.r_[True, lengths > 1e-6]]
    distances = np.r_[0, np.cumsum(np.linalg.norm(np.diff(polyline, axis=0), axis=1))]
    sample_distances = np.arange(horizon) * SPEED * DT
    return np.c_[
        np.interp(sample_distances, distances, polyline[:, 0]),
        np.interp(sample_distances, distances, polyline[:, 1]),
    ]


def run_route(solver, route: np.ndarray, horizon: int = HORIZON):
    """Apply one bounded MPC control, integrate twice, then test active target.

    This exactly preserves the original ordered acceptance event convention:
    samples 2,4,... are control endpoints, and every target receives at least
    one interval before acceptance. Shifted previous solutions warm-start the
    following optimization. No trajectory is interpolated or geometrically fit.
    """
    depot = route[-1]
    direction = route[0] - depot
    state = np.r_[depot, np.arctan2(direction[1], direction[0])]
    trajectory, controls, events, statuses = [state.copy()], [], [], []
    state_count = 3 * (horizon + 1)
    lower = np.r_[np.full(state_count, -1e9), np.full(horizon, -DELTA_MAX)]
    upper = np.r_[np.full(state_count, 1e9), np.full(horizon, DELTA_MAX)]
    previous_delta, guess = 0., None
    for j, target in enumerate(route):
        for _ in range(200):
            reference = references(state, route[j:], horizon)
            params = np.r_[state, previous_delta, reference.flatten()]
            arguments = dict(p=params, lbx=lower, ubx=upper, lbg=0, ubg=0)
            if guess is not None:
                arguments["x0"] = guess
            solution = solver(**arguments)
            statuses.append(solver.stats()["return_status"])
            if not solver.stats()["success"]:
                raise RuntimeError(f"MPC solve did not converge: {statuses[-1]}")
            values = np.array(solution["x"]).flatten()
            predicted_controls = values[state_count:]
            delta = float(np.clip(predicted_controls[0], -DELTA_MAX, DELTA_MAX))
            previous_delta = delta
            controls.append(delta)
            for _ in range(2):
                state = state + DT / 2 * np.array([
                    SPEED * np.cos(state[2]), SPEED * np.sin(state[2]),
                    SPEED / TURNING_LENGTH * np.tan(delta),
                ])
                trajectory.append(state.copy())
            predicted_states = values[:state_count].reshape(-1, 3)
            shifted_states = np.vstack([predicted_states[1:], predicted_states[-1]])
            shifted_states[0] = state
            guess = np.r_[shifted_states.flatten(), predicted_controls[1:], predicted_controls[-1]]
            if np.linalg.norm(state[:2] - target) < TOLERANCE:
                events.append(len(trajectory) - 1)
                break
        else:
            raise RuntimeError(f"Did not reach ordered target {j + 1}")
    return np.array(trajectory), np.array(controls), np.array(events), statuses


def acceptance_events(trajectory, route):
    start, events = 2, []
    for target in route:
        samples = np.arange(start, len(trajectory), 2)
        hits = np.flatnonzero(np.linalg.norm(trajectory[samples, :2] - target, axis=1) < TOLERANCE)
        assert len(hits), "An ordered target was missed"
        accepted = int(samples[hits[0]])
        events.append(accepted)
        start = accepted + 2
    assert events[-1] == len(trajectory) - 1, "Route must end at depot acceptance"
    return np.asarray(events)


def route_metrics(trajectory, route):
    events = acceptance_events(trajectory, route)
    return {
        "length_km": float(np.linalg.norm(np.diff(trajectory[:, :2], axis=0), axis=1).sum()),
        "samples": int(len(trajectory)),
        "own_centroids_accepted": len(route) - 1,
        "all_own_targets_accepted_in_order": True,
        "depot_accepted": True,
        "final_depot_distance_km": float(np.linalg.norm(trajectory[-1, :2] - route[-1])),
        "acceptance_samples": events.tolist(),
    }


def validate(original, candidate):
    old_metrics, new_metrics = [], []
    for j in range(3):
        route = candidate[f"plans_level4_route{j}"]
        assert np.array_equal(route, original[f"plans_level4_route{j}"]), "Tour order changed"
        trajectory = candidate[f"plans_level4_trajectory{j}"]
        control = candidate[f"plans_level4_control{j}"]
        assert np.isfinite(trajectory).all() and np.isfinite(control).all()
        assert len(trajectory) == 2 * len(control) + 1
        assert np.allclose(trajectory[0, :2], route[-1])
        assert np.max(np.abs(control)) <= DELTA_MAX + 1e-12
        assert np.allclose(np.linalg.norm(np.diff(trajectory[:, :2], axis=0), axis=1), SPEED * DT / 2)
        # Independently verify every stored execution substep against the model.
        states, next_states = trajectory[:-1], trajectory[1:]
        delta = np.repeat(control, 2)
        predicted = states + DT / 2 * np.c_[
            SPEED * np.cos(states[:, 2]), SPEED * np.sin(states[:, 2]),
            SPEED / TURNING_LENGTH * np.tan(delta),
        ]
        assert np.allclose(predicted, next_states, atol=1e-10)
        events = acceptance_events(trajectory, route)
        assert np.array_equal(events, candidate[f"plans_level4_acceptance{j}"])
        old_metrics.append(route_metrics(original[f"plans_level4_trajectory{j}"], route))
        new_metrics.append(route_metrics(trajectory, route))
    return old_metrics, new_metrics


def original_horizon_comparison(original, horizons=(150, 200)):
    sys.path.insert(0, str(HERE.parent / "code"))
    from planner import ackermann_mpc, run_mpc

    results = []
    for horizon in horizons:
        solver = ackermann_mpc(N=horizon, dt=DT, L=TURNING_LENGTH, v0=SPEED)
        rows = []
        for j in range(3):
            route = original[f"plans_level4_route{j}"]
            direction = route[0] - route[-1]
            initial = np.r_[route[-1], np.arctan2(direction[1], direction[0])]
            started = time.monotonic()
            trajectory, reached = run_mpc(
                solver, initial, route, N=horizon, dt=DT, L=TURNING_LENGTH,
                v0=SPEED, delta_max=DELTA_MAX, max_iters_per_wp=500,
                wp_tol=TOLERANCE, max_steps=5000, return_status=True,
                integration_substeps=2,
            )
            assert all(reached) and len(reached) == len(route)
            row = route_metrics(trajectory, route)
            row["generation_seconds"] = time.monotonic() - started
            rows.append(row)
            print(f"Original N={horizon}, UAV {j + 1}: {row['length_km']:.1f} km", flush=True)
        results.append({"horizon_steps": horizon, "per_uav": rows,
                        "aggregate_length_km": sum(row["length_km"] for row in rows)})
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rebuild", action="store_true")
    parser.add_argument("--compare-horizons", action="store_true")
    args = parser.parse_args()
    original = np.load(ORIGINAL, allow_pickle=False)
    solver_statuses = None
    if args.rebuild:
        solver = make_solver(HORIZON)
        arrays = {"plans_level4_depot": original["plans_level4_route0"][-1]}
        solver_statuses = []
        for j in range(3):
            route = original[f"plans_level4_route{j}"]
            trajectory, controls, events, statuses = run_route(solver, route)
            arrays[f"plans_level4_route{j}"] = route
            arrays[f"plans_level4_trajectory{j}"] = trajectory
            arrays[f"plans_level4_control{j}"] = controls
            arrays[f"plans_level4_acceptance{j}"] = events
            solver_statuses.append({status: statuses.count(status) for status in sorted(set(statuses))})
        validate(original, arrays)
        np.savez_compressed(OUTPUT, **arrays)
    candidate = np.load(OUTPUT, allow_pickle=False)
    baseline, improved = validate(original, candidate)
    previous = json.loads(REPORT.read_text()) if REPORT.exists() else {}
    original_tests = previous.get("original_cost_longer_horizon_tests", [])
    if args.compare_horizons:
        original_tests = original_horizon_comparison(original)
    old_length = sum(row["length_km"] for row in baseline)
    new_length = sum(row["length_km"] for row in improved)
    report = {
        "scope": "Presentation-only regenerated experiment for Figure 4 level 4, 3 UAVs; original paper arrays and code remain unchanged.",
        "method": "Route-aware reference-tracking nonlinear MPC, temporally discounted tracking cost and shifted-solution warm start.",
        "horizon_steps": HORIZON,
        "horizon_model_time_units": HORIZON * DT,
        "horizon_distance_km": HORIZON * DT * SPEED,
        "dt": DT, "integration_substeps": 2, "speed_km_per_model_time_unit": SPEED,
        "turning_length_km": TURNING_LENGTH, "steering_limit_degrees": 60,
        "minimum_turning_radius_km": float(TURNING_LENGTH / np.tan(DELTA_MAX)),
        "waypoint_tolerance_km": TOLERANCE,
        "weights": {"position": 5, "steering": .05, "steering_change": 15,
                    "previous_control_change": 12, "second_difference": 6,
                    "tracking_and_steering_discount": "exp(-k/15)"},
        "unchanged": ["centroids", "k-means allocation", "exact Hamiltonian waypoint tour order", "depot", "constant-speed bicycle kinematics", "60-degree steering bound", "two execution substeps", "3 km acceptance disks"],
        "baseline": {"horizon_steps": 100, "method": "Original cold-started active-target-only MPC", "aggregate_length_km": old_length, "per_uav": baseline},
        "selected": {"aggregate_length_km": new_length, "reduction_percent": 100 * (old_length - new_length) / old_length, "per_uav": improved},
        "original_cost_longer_horizon_tests": original_tests,
        "solver_statuses_per_uav": solver_statuses or previous.get("solver_statuses_per_uav"),
        "validation": "All assigned centroids accepted in their unchanged order, followed by depot; controls bounded; every stored substep matches constant-speed dynamics; no curve fitting or interpolation used to generate paths.",
        "interpretation": "A longer horizon alone repeats the stationary active target farther into the future. Route look-ahead, a near-term tracking emphasis, and warm starts avoid unnecessary circling in this example. This is an illustrative control improvement, not a new result from the paper or a claim of globally optimal fixed-wing tours.",
    }
    if args.rebuild or args.compare_horizons:
        REPORT.write_text(json.dumps(report, indent=2) + "\n")
    print(f"Validated all 3 UAVs: {old_length:.0f} -> {new_length:.0f} km ({report['selected']['reduction_percent']:.1f}% shorter).")


if __name__ == "__main__":
    main()
