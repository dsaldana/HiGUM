#!/usr/bin/env python3
"""Build the closing slide's text point cloud and genuine binary GMM hierarchy.

This is a two-dimensional application of the paper's spatial partition method,
not additional experimental data. Every level is fitted with the original
``code/generate_hierarchical_partitions.py::split_once`` implementation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile

os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "higum-mpl"))
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / "code"))
from generate_hierarchical_partitions import split_once


def font_path() -> Path:
    candidates = (
        Path("/System/Library/Fonts/Supplemental/Arial Black.ttf"),
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
        Path("/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf"),
    )
    for candidate in candidates:
        if candidate.exists():
            return candidate
    raise FileNotFoundError("Install Arial Black or DejaVu Sans Bold to regenerate the text mask")


def validate(arrays: dict[str, np.ndarray]) -> None:
    points = arrays["points"]
    assert points.shape == (65536, 2)
    for depth in range(11):
        prefix = f"level{depth}"
        labels = arrays[f"{prefix}_labels"]
        means = arrays[f"{prefix}_means"]
        covariances = arrays[f"{prefix}_covariances"]
        counts = arrays[f"{prefix}_counts"]
        assert means.shape == (2**depth, 2)
        assert counts.sum() == len(points) and counts.min() >= 3
        assert np.all(np.linalg.eigvalsh(covariances) > 0)
        assert np.array_equal(np.unique(labels), np.arange(2**depth))
        if depth:
            assert np.array_equal(labels // 2, arrays[f"level{depth-1}_labels"])
        for node, mean in enumerate(means):
            assert np.allclose(mean, points[labels == node].mean(axis=0))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--output", type=Path, default=HERE / "assets")
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    asset = output / "thank_you.npz"
    if asset.exists() and not args.force:
        with np.load(asset, allow_pickle=False) as data:
            validate(dict(data))
        print(f"Validated {asset}")
        return

    seed = 2026
    rng = np.random.default_rng(seed)
    font = ImageFont.truetype(str(font_path()), 300)
    bounds = font.getbbox("Thank you")
    mask = Image.new("L", (bounds[2] - bounds[0] + 8, bounds[3] - bounds[1] + 8))
    ImageDraw.Draw(mask).text((4 - bounds[0], 4 - bounds[1]), "Thank you", fill=255, font=font)
    y, x = np.nonzero(np.asarray(mask) > 240)
    indices = rng.choice(len(x), 65536, replace=True)
    # Jitter removes identical pixel centers. Coordinates have no physical units.
    points = np.column_stack((x[indices], -y[indices])).astype(float)
    points += rng.uniform(-0.45, 0.45, points.shape)
    points -= (points.max(axis=0) + points.min(axis=0)) / 2
    points *= 10.8 / np.ptp(points[:, 0])
    points[:, 1] += 0.05
    arrays = {"points": points}
    partitions = [np.arange(len(points))]
    stats = []
    for depth in range(11):
        if depth:
            partitions = split_once(points, partitions, seed)
        prefix = f"level{depth}"
        labels = np.empty(len(points), dtype=np.int16)
        means, covariances, counts = [], [], []
        for node, indices in enumerate(partitions):
            if len(indices) < 3:
                raise ValueError(f"Insufficient samples in level {depth}, node {node}")
            subset = points[indices]
            labels[indices] = node
            means.append(subset.mean(axis=0))
            covariances.append(np.cov(subset, rowvar=False) + 1e-6 * np.eye(2))
            counts.append(len(indices))
        arrays[f"{prefix}_labels"] = labels
        arrays[f"{prefix}_means"] = np.asarray(means)
        arrays[f"{prefix}_covariances"] = np.asarray(covariances)
        arrays[f"{prefix}_counts"] = np.asarray(counts, dtype=np.int32)
        stats.append({"depth": depth, "gaussians": 2**depth, "smallest_partition": min(counts)})
        print(f"Fitted {2**depth:4d} nodes; minimum {min(counts)} samples", flush=True)
    validate(arrays)
    np.savez_compressed(asset, **arrays)
    source = ROOT / "code" / "generate_hierarchical_partitions.py"
    metadata = {
        "purpose": "Illustrative closing slide; spatial points sampled inside the letter strokes of Thank you.",
        "method": "Original split_once: recursive binary full-covariance GaussianMixture EM with hard maximum-responsibility assignment and reg_covar=1e-6. Means and unbiased sample covariances are recomputed per partition, as in the paper slides.",
        "dimensions": 2,
        "note": "A planar demonstration of the paper's method, not smoke measurements or a reported experiment.",
        "samples": len(points), "seed": seed,
        "font": str(font_path()),
        "generator_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "display": "Filled 2-standard-deviation covariance ellipses; every consecutive pair of children shares a parent.",
        "levels": stats,
        "validation": "All 11 levels partition all samples, preserve binary ancestry, match empirical means, and have positive-definite covariances and >=3 samples per node.",
    }
    (output / "thank_you.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(f"Saved {asset}")


if __name__ == "__main__":
    main()
