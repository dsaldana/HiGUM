#!/usr/bin/env python3
"""Rebuild numeric animation assets from the paper's original Python methods.

No paper images are used or rendered.  NumPy, scikit-learn, Matplotlib (needed
by the imported original modules), and CasADi/IPOPT are required to regenerate
the assets.  The committed NPZ is enough for rendering the presentation.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile

# Headless imports: the original generators import pyplot, but this script
# calls only their numeric functions.  Limit BLAS threads for predictable runs.
os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "higum-mpl"))
os.environ.setdefault("XDG_CACHE_HOME", str(Path(tempfile.gettempdir()) / "higum-cache"))
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "code"))

import numpy as np

from generate_hierarchical_partitions import hierarchy_levels
from generate_single_ellipsoid import generate_point_cloud
from generate_three_source_hierarchy import generate_three_source_plume
from generate_wrf_hgm_hierarchy import extract_point_cloud, hierarchy
from generate_wrf_uav_plans import allocate_and_order, plan_routes


def store_hierarchy(
    arrays: dict[str, np.ndarray], prefix: str, points: np.ndarray,
    concentration: np.ndarray, levels: dict[int, list[np.ndarray]],
    max_level: int, covariance_regularization: float = 0.0,
) -> None:
    """Store full positions, concentrations, labels, and node sufficient stats.

    Level L has 2**L nodes in parent-to-children order; children 2*j and 2*j+1
    belong to parent j. Labels are node indices into each level's statistics.
    The Gaussian models position; concentration is an unweighted scalar mean.
    """
    arrays[f"{prefix}_points"] = np.asarray(points, dtype=np.float64)
    arrays[f"{prefix}_concentration"] = np.asarray(concentration, dtype=np.float64)
    for level in range(max_level + 1):
        partitions = levels[2**level]
        key = f"{prefix}_level{level}"
        labels = np.empty(len(points), dtype=np.int16)
        means, covariances, averages, counts = [], [], [], []
        for node, indices in enumerate(partitions):
            subset = points[indices]
            labels[indices] = node
            means.append(subset.mean(axis=0))
            covariances.append(
                np.cov(subset, rowvar=False)
                + covariance_regularization * np.eye(3)
            )
            averages.append(concentration[indices].mean())
            counts.append(len(indices))
        arrays[f"{key}_means"] = np.asarray(means)
        arrays[f"{key}_covariances"] = np.asarray(covariances)
        arrays[f"{key}_concentration"] = np.asarray(averages)
        arrays[f"{key}_labels"] = labels
        arrays[f"{key}_counts"] = np.asarray(counts, dtype=np.int32)


def validate(arrays: dict[str, np.ndarray]) -> None:
    """Check partition integrity, Gaussian statistics, and original MPC output."""
    for prefix, depth in (("fig1", 4), ("fig2", 3), ("wrf", 5)):
        points = arrays[f"{prefix}_points"]
        assert points.ndim == 2 and points.shape[1] == 3
        for level in range(depth + 1):
            key = f"{prefix}_level{level}"
            labels = arrays[f"{key}_labels"]
            means = arrays[f"{key}_means"]
            covariances = arrays[f"{key}_covariances"]
            assert len(means) == 2**level
            assert arrays[f"{key}_counts"].sum() == len(points)
            assert np.array_equal(np.unique(labels), np.arange(2**level))
            assert np.all(np.linalg.eigvalsh(covariances) > 0)
            for node in range(2**level):
                assert np.allclose(means[node], points[labels == node].mean(axis=0))
            if level > 0:
                assert np.array_equal(labels // 2, arrays[f"{prefix}_level{level-1}_labels"])
    for level, n_uavs in ((3, 3), (4, 3), (5, 5)):
        depot = arrays[f"plans_level{level}_depot"]
        total_targets = 0
        for vehicle in range(n_uavs):
            route = arrays[f"plans_level{level}_route{vehicle}"]
            trajectory = arrays[f"plans_level{level}_trajectory{vehicle}"]
            assert np.allclose(route[-1], depot)
            assert np.allclose(trajectory[0, :2], depot)
            assert np.linalg.norm(trajectory[-1, :2] - depot) < 3.0
            assert trajectory.shape[1] == 3 and np.isfinite(trajectory).all()
            # Original MPC execution uses speed 10 and substep duration .05:
            # every stored displacement must therefore be 0.5 km long.
            distances = np.linalg.norm(np.diff(trajectory[:, :2], axis=0), axis=1)
            assert np.allclose(distances, 0.5)
            # The waypoint state machine tests at the end of each two-substep
            # execution interval and must accept every target in order.
            checked_positions = trajectory[2::2, :2]
            next_step = 0
            for waypoint in route:
                accepted = np.flatnonzero(
                    np.linalg.norm(checked_positions[next_step:] - waypoint, axis=1) < 3.0
                )
                assert len(accepted), "An ordered MPC waypoint was not reached"
                next_step += int(accepted[0]) + 1
            total_targets += len(route) - 1
        assert total_targets == 2**level


def sha256(path: Path) -> str:
    """Identify generator versions without including the large input array."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parents[1] / "assets")
    parser.add_argument("--force", action="store_true", help="recompute even if an asset bundle exists")
    args = parser.parse_args()
    output = args.output.resolve()
    npz_path = output / "higum_data.npz"
    metadata_path = output / "metadata.json"
    if npz_path.exists() and metadata_path.exists() and not args.force:
        with np.load(npz_path, allow_pickle=False) as existing:
            validate(dict(existing))
        print(f"Validated existing assets: {npz_path}")
        print("Pass --force to recompute the original GMMs and nonlinear MPC.")
        return

    output.mkdir(parents=True, exist_ok=True)
    arrays: dict[str, np.ndarray] = {}
    print("Figure 1: original 900-sample three-source plume, levels 0–4", flush=True)
    points, concentration = generate_three_source_plume(300, 23)
    levels = {1: [np.arange(len(points))], **hierarchy_levels(points, 23)}
    store_hierarchy(arrays, "fig1", points, concentration, levels, 4)

    print("Figure 2: original 650-sample curved plume, levels 0–3", flush=True)
    points, concentration = generate_point_cloud(650, 17)
    levels = {1: [np.arange(len(points))], **hierarchy_levels(points, 17)}
    store_hierarchy(arrays, "fig2", points, concentration, levels, 3)

    print("Figure 3: original every-50th-voxel WRF-FIRE plume, levels 0–5", flush=True)
    points, concentration = extract_point_cloud(ROOT / "code" / "fire_smoke_data.npy")
    levels = hierarchy(points, 0)
    store_hierarchy(arrays, "wrf", points, concentration, levels, 5, 1e-6)

    cases = []
    depot = np.array([8.0, 20.0])
    for level, n_uavs in ((3, 3), (4, 3), (5, 5)):
        print(f"Figure 4: original level-{level} allocation, exact tours and {n_uavs} MPC trajectories", flush=True)
        means_xy = arrays[f"wrf_level{level}_means"][:, :2]
        routes = allocate_and_order(means_xy, depot, n_uavs, seed=0)
        # This function raises if a target is not reached. No synthetic or
        # interpolated replacement routes are generated on failure.
        trajectories = plan_routes(routes, depot)
        arrays[f"plans_level{level}_depot"] = depot
        cases.append({"level": level, "n_uavs": n_uavs, "trajectories": []})
        for vehicle, (route, trajectory) in enumerate(zip(routes, trajectories)):
            arrays[f"plans_level{level}_route{vehicle}"] = route
            arrays[f"plans_level{level}_trajectory{vehicle}"] = trajectory
            cases[-1]["trajectories"].append({
                "vehicle_index": vehicle,
                "waypoints_excluding_depot": len(route) - 1,
                "samples": len(trajectory),
                "model_duration": (len(trajectory) - 1) * 0.05,
                "length_km": float(np.linalg.norm(np.diff(trajectory[:, :2], axis=0), axis=1).sum()),
                "final_depot_distance_km": float(np.linalg.norm(trajectory[-1, :2] - depot)),
            })

    print("Validating all hierarchy levels and MPC trajectories", flush=True)
    validate(arrays)
    np.savez_compressed(npz_path, **arrays)
    metadata = {
        "schema_version": 1,
        "paper": "HiGUM: A Hierarchical Gaussian Model for Cooperative Multi-UAV Smoke Monitoring",
        "provenance": "Numeric arrays recomputed with the original generators in ../code. No paper figure images are used.",
        "generators_sha256": {
            name: sha256(ROOT / "code" / name) for name in (
                "generate_three_source_hierarchy.py", "generate_single_ellipsoid.py",
                "generate_hierarchical_partitions.py", "generate_wrf_hgm_hierarchy.py",
                "generate_wrf_uav_plans.py", "planner.py",
            )
        },
        "datasets": {
            "fig1": {"samples": 900, "seed": 23, "levels": [0, 1, 2, 3, 4], "coordinate_units": "synthetic spatial units", "color_scale": "linear"},
            "fig2": {"samples": 650, "seed": 17, "levels": [0, 1, 2, 3], "coordinate_units": "synthetic spatial units", "color_scale": "linear"},
            "wrf": {"samples": len(points), "seed": 0, "levels": [0, 1, 2, 3, 4, 5], "coordinate_units": "km", "color_scale": "logarithmic", "time_index": 3, "valid_voxel_stride": 50, "minimum_concentration": 1e-6, "source": "code/fire_smoke_data.npy", "full_dataset_samples_reported_in_paper": 257896},
        },
        "schema": {
            "{prefix}_points": "(N,3) positions, original sample ordering; prefix is fig1, fig2 or wrf",
            "{prefix}_concentration": "(N,) PM2.5 concentration values in micrograms/m^3",
            "{prefix}_level{L}_means": "(2**L,3) arithmetic node position means",
            "{prefix}_level{L}_covariances": "(2**L,3,3) unbiased sample covariances; WRF adds 1e-6 I as in original generator",
            "{prefix}_level{L}_concentration": "(2**L,) arithmetic concentration means; concentration does not weight GMM fitting",
            "{prefix}_level{L}_counts": "(2**L,) number of original samples per node",
            "{prefix}_level{L}_labels": "(N,) node assignment; parent index = child index // 2",
            "plans_level{L}_depot": "(2,) shared initial position in km: [8,20]",
            "plans_level{L}_route{u}": "(K+1,2) exact depot-aware Hamiltonian waypoint order, ending at depot; initial depot implicit",
            "plans_level{L}_trajectory{u}": "(T,3) original MPC states [x_km,y_km,yaw_radians]; every .05 model time unit, starting at depot; zero-based UAV index",
        },
        "ellipsoids": {"standard_deviations": 2, "meaning": "points = mean + eigenvectors @ (2*sqrt(eigenvalues) * unit_sphere); no stored raster/vector figure assets"},
        "planning": {
            "cases": cases,
            "allocation": "KMeans(random_state=0,n_init=20)",
            "ordering": "exact_depot_cycle: exhaustive shortest depot-aware Hamiltonian cycle",
            "tracking": "original Ackermann nonlinear MPC / CasADi IPOPT",
            "horizon": 100, "dt": 0.1, "integration_substeps": 2,
            "turning_length_km": 5.0, "speed_km_per_model_time_unit": 10.0,
            "steering_limit_degrees": 60, "waypoint_tolerance_km": 3.0,
            "playback": "Animate stored samples at a convenient presentation rate. Model time units are not a claim of physical flight seconds. A waypoint is accepted within a 3 km disk; trajectories need not pass through centroid markers or close exactly at the depot.",
        },
        "runtime_benchmark": {
            "paper_settings": {"full_dataset_samples": 257896, "maximum_level": 15, "repetitions": 5},
            "raw_measurements_available": False,
            "note": "The repository stores a plot but no raw timing measurements. Slides must not invent digitized runtime values. Re-run code/benchmark_hgm_runtime.py for a new machine-specific benchmark.",
        },
        "validation": "Partition counts/parent-child labels/statistical means/positive covariance eigenvalues checked. All ordered MPC waypoints are reached within 3 km at control interval endpoints. Trajectories start at depot, finish inside its 3 km acceptance disk and advance .5 km per execution substep.",
    }
    metadata_path.write_text(json.dumps(metadata, indent=2) + "\n")
    print(f"Saved {npz_path} ({npz_path.stat().st_size / 1024:.0f} KiB)", flush=True)
    print(f"Saved {metadata_path}", flush=True)


if __name__ == "__main__":
    main()
