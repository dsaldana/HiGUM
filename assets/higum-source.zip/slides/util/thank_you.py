"""Click-controlled closing animation using precomputed binary GMM statistics."""
from pathlib import Path

import numpy as np
from manim import *
from manimpango import list_fonts

HERE = Path(__file__).resolve().parents[1]
INK = "#EDF2F7"
MUTED = "#9CADC2"
CYAN = "#62D9E8"
TEAL = "#34BBAE"
FONT = next((f for f in ("Arial", "DejaVu Sans", "Liberation Sans") if f in list_fonts()), "sans-serif")


def _label(text, size=24, color=INK):
    return Text(text, font=FONT, font_size=size, color=color)


def _gaussians(data, depth):
    means = data[f"level{depth}_means"]
    covariances = data[f"level{depth}_covariances"]
    group = VGroup()
    for mean, covariance in zip(means, covariances):
        values, vectors = np.linalg.eigh(covariance)
        # Eigenvalues are ascending; the second eigenvector is the long axis.
        color = interpolate_color(ManimColor(CYAN), ManimColor(TEAL), float((mean[0] + 5.4) / 10.8))
        ellipse = Ellipse(
            width=4 * np.sqrt(values[1]), height=4 * np.sqrt(values[0]),
            stroke_color=color, stroke_width=0.7 if depth < 7 else 0.35,
            stroke_opacity=0.85, fill_color=color,
            fill_opacity=0.48 if depth < 7 else 0.77,
        )
        ellipse.rotate(np.arctan2(vectors[1, 1], vectors[0, 1]))
        ellipse.move_to([mean[0], mean[1], 0])
        group.add(ellipse)
    return group


def thank_you(scene):
    """Draw Thank you, sample its strokes, then refine 8→…→1,024 Gaussians.

    All fitting happened in util/prepare_thank_you.py; rendering never substitutes
    decorative or hand-placed ellipses for the computed hierarchy.
    """
    asset = HERE / "assets" / "thank_you.npz"
    if not asset.exists():
        raise FileNotFoundError("Missing closing assets. Run: python util/prepare_thank_you.py")
    with np.load(asset, allow_pickle=False) as archive:
        data = dict(archive)
    scene.page("Contact: saldana@lehigh.edu", "HiGUM  /  LARS 2026 ")
    subtitle = _label("One point cloud. Many resolutions.", 24, MUTED).move_to([0, 1.95, 0])
    word_font = "Arial Black" if "Arial Black" in list_fonts() else FONT
    word = Text("Thank you", font=word_font, weight=BOLD, color=INK).scale_to_fit_width(10.8).move_to([0, 0.05, 0])
    scene.play(Write(word), FadeIn(subtitle), run_time=2.5)
    scene.pause("Closing: Thank you. Click to turn the letter strokes into spatial samples.")

    points = data["points"]
    ids = np.random.default_rng(2026).choice(len(points), 2800, replace=False)
    dots = VGroup(*[Dot([*points[j], 0], radius=0.012, color=CYAN, fill_opacity=0.8, stroke_width=0) for j in ids])
    counter = _label("65,536 spatial samples", 25, CYAN).move_to([0, -1.85, 0])
    description = _label("Recursive binary GMM  •  full covariance  •  2-D illustration", 18, MUTED).move_to([0, -2.48, 0])
    scene.play(FadeOut(word), FadeIn(dots), FadeIn(counter), FadeIn(description), run_time=2.7)
    scene.pause("65,536 samples inside the text strokes. Display shows a deterministic subset. Click to fit 8 Gaussian nodes.")

    old = None
    for depth in range(3, 11):
        count = 2**depth
        new = _gaussians(data, depth)
        new_counter = _label(f"{count:,} Gaussians", 25, CYAN).move_to(counter)
        if old is None:
            scene.play(dots.animate.set_opacity(0.12), FadeIn(new), Transform(counter, new_counter), run_time=3.0)
        else:
            # The exact child ordering retained in the asset gives a true
            # parent-to-two-children morph at every doubling of resolution.
            wrappers = [VGroup(new[2*j], new[2*j+1]) for j in range(len(old))]
            scene.play(*[ReplacementTransform(parent, children)
                         for parent, children in zip(list(old), wrappers)],
                       Transform(counter, new_counter), run_time=3.0)
            scene.remove(old, *wrappers)
            scene.add(new)
        old = new
        if depth == 10:
            scene.play(FadeOut(dots), run_time=0.8)
        scene.pause(f"Thank you: {count:,} full-covariance Gaussian nodes. "
                    + ("End of presentation." if depth == 10 else "Click to double the resolution."))
