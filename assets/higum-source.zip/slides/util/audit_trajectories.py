#!/usr/bin/env python3
"""Audit route ownership and replay the original MPC waypoint state machine.

Reads stored numerical assets only; does not regenerate or modify trajectories.
Run from slides/: python util/audit_trajectories.py
"""
from pathlib import Path
import json
import numpy as np

HERE = Path(__file__).resolve().parents[1]
TOLERANCE_KM = 3.0


def audit():
    data = np.load(HERE / "assets" / "higum_data.npz", allow_pickle=False)
    cases = []
    for level, count in ((3, 3), (4, 3), (5, 5)):
        routes = [data[f"plans_level{level}_route{j}"] for j in range(count)]
        centers = data[f"wrf_level{level}_means"][:, :2]
        assigned = np.vstack([r[:-1] for r in routes])
        assert len(assigned) == len(centers)
        matches = np.linalg.norm(assigned[:, None, :] - centers[None, :, :], axis=-1) < 1e-8
        assert np.all(matches.sum(0) == 1) and np.all(matches.sum(1) == 1)
        vehicles = []
        for j, route in enumerate(routes):
            trajectory = data[f"plans_level{level}_trajectory{j}"]
            depot = data[f"plans_level{level}_depot"]
            assert np.allclose(trajectory[0, :2], depot)
            assert np.allclose(route[-1], depot)
            assert np.allclose(np.linalg.norm(np.diff(trajectory[:, :2], axis=0), axis=1), .5)
            events = []
            start = 2
            for target in route:
                # Exactly run_mpc: one test after each two .05 execution substeps;
                # every new target gets at least one .1 control interval.
                samples = np.arange(start, len(trajectory), 2)
                distances = np.linalg.norm(trajectory[samples, :2] - target, axis=1)
                hits = np.flatnonzero(distances < TOLERANCE_KM)
                assert len(hits), f"Level {level} UAV {j+1}: target not reached"
                sample = int(samples[hits[0]])
                events.append({"sample": sample, "distance_km": float(distances[hits[0]])})
                start = sample + 2
            assert events[-1]["sample"] == len(trajectory) - 1
            close_passes = []
            for other, other_route in enumerate(routes):
                if other == j:
                    continue
                for node, target in enumerate(other_route[:-1]):
                    distances = np.linalg.norm(trajectory[:, :2] - target, axis=1)
                    sample = int(np.argmin(distances))
                    if distances[sample] < 1.2:
                        active = int(np.searchsorted([e["sample"] for e in events], sample, side="right"))
                        close_passes.append({
                            "owner_uav": other + 1, "owner_node_in_route": node + 1,
                            "closest_sample": sample, "closest_distance_km": float(distances[sample]),
                            "own_active_target_in_route": active + 1,
                        })
            vehicles.append({
                "uav": j + 1, "waypoints": len(route) - 1,
                "accepted_targets_including_depot": events,
                "unassigned_centroid_close_passes_within_1_2km": close_passes,
            })
        cases.append({"level": level, "uavs": vehicles})
    return {
        "result": "All 11 stored trajectories match their indexed route and color; all assigned centroids are accepted in order, then the depot.",
        "interpretation": "An unassigned node can lie near a fixed-wing trajectory without becoming its target or an accepted visit. Targets advance within the original 3 km tolerance at control interval endpoints.",
        "waypoint_tolerance_km": TOLERANCE_KM,
        "trajectory_changes": "None",
        "cases": cases,
    }


if __name__ == "__main__":
    result = audit()
    destination = HERE / "assets" / "trajectory_audit.json"
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(result["result"])
    print(f"Audit written to {destination}")
