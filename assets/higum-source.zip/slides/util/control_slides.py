"""Click-controlled UAV dynamics and NMPC slides, with an analytic Dubins path."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from manim import *
from manimpango import list_fonts

HERE = Path(__file__).resolve().parents[1]
INK = "#EDF2F7"
MUTED = "#9CADC2"
CYAN = "#62D9E8"
ORANGE = "#FFB15B"
FONT = next((f for f in ("Arial", "DejaVu Sans", "Liberation Sans") if f in list_fonts()), "sans-serif")
DUBINS_SOURCE = "https://ompl.kavrakilab.org/core/classompl_1_1base_1_1DubinsStateSpace.html"


def _label(text, size=24, color=INK):
    return Text(text, font=FONT, font_size=size, color=color)


class DubinsIllustration:
    """An L-S-R path with tangent joins and arc-length-parameterized motion.

    The two circular arcs have the same minimum turning radius. The straight
    segment has zero curvature. Coordinates are schematic, not paper data.
    """
    def __init__(self):
        self.radius = 1.05
        self.angle = PI / 5
        self.straight = 3.2
        self.start = np.array([1.4, -1.15, 0.0])
        self.arc_length = self.radius * self.angle
        self.length = 2 * self.arc_length + self.straight

    def pose(self, distance):
        r, a = self.radius, self.angle
        distance = float(np.clip(distance, 0, self.length))
        first_end = self.start + r * np.array([np.sin(a), 1 - np.cos(a), 0])
        if distance <= self.arc_length:
            heading = distance / r
            point = self.start + r * np.array([np.sin(heading), 1 - np.cos(heading), 0])
        elif distance <= self.arc_length + self.straight:
            heading = a
            point = first_end + (distance - self.arc_length) * np.array([np.cos(a), np.sin(a), 0])
        else:
            heading = a - (distance - self.arc_length - self.straight) / r
            straight_end = first_end + self.straight * np.array([np.cos(a), np.sin(a), 0])
            point = straight_end + r * np.array([np.sin(a) - np.sin(heading), np.cos(heading) - np.cos(a), 0])
        return point, heading

    def segments(self):
        first_end, _ = self.pose(self.arc_length)
        straight_end, _ = self.pose(self.arc_length + self.straight)
        return VGroup(
            Arc(radius=self.radius, start_angle=-PI / 2, angle=self.angle,
                arc_center=self.start + UP * self.radius),
            Line(first_end, straight_end),
            Arc(radius=self.radius, start_angle=PI / 2 + self.angle, angle=-self.angle,
                arc_center=straight_end + self.radius * np.array([np.sin(self.angle), -np.cos(self.angle), 0])),
        )


def _uav_glyph():
    """Editable top-view fixed-wing symbol, with its nose along +x."""
    outline = np.array([
        [.36, 0], [.18, .045], [.04, .045], [-.08, .32], [-.17, .32],
        [-.10, .04], [-.28, .035], [-.34, .14], [-.40, .14], [-.36, 0],
        [-.40, -.14], [-.34, -.14], [-.28, -.035], [-.10, -.04],
        [-.17, -.32], [-.08, -.32], [.04, -.045], [.18, -.045],
    ])
    return Polygon(*np.c_[outline, np.zeros(len(outline))],
                   fill_color=ORANGE, fill_opacity=1, stroke_color=INK, stroke_width=.8).scale(.75)


def uav_dynamics(scene):
    scene.page("Fixed-wing UAV dynamics", "Paper: Reduced planar model  /  Dubins path illustration")
    equations = VGroup(
        MathTex(r"x_{t+1}=x_t+\Delta t\,v_0\cos\psi_t", font_size=33),
        MathTex(r"y_{t+1}=y_t+\Delta t\,v_0\sin\psi_t", font_size=33),
        MathTex(r"\psi_{t+1}=\psi_t+\Delta t\,\frac{v_0}{L}\tan\delta_t", font_size=33),
    ).arrange(DOWN, aligned_edge=LEFT, buff=.3).move_to([-3.2, 1.15, 0])
    constants = _label("Constant speed and altitude", 22, MUTED).move_to([-3.2, -.55, 0])
    steering = MathTex(r"|\delta_t|\leq\delta_{\max}", font_size=30).move_to([-3.2, -1.05, 0])
    photo = ImageMobject(str(HERE / "assets/monitoring_uav.jpg")).scale_to_fit_width(4.5)
    photo.move_to([-3.2, -2.15, 0])
    source = json.loads((HERE / "assets/monitoring_uav_source.json").read_text())
    name = source["short_caption"].split(" · ")[0]
    credit = _label(name + " · " + source["credit"], 11, MUTED).move_to([-3.2, -3.02, 0])
    scene.play(Write(equations), FadeIn(constants), FadeIn(steering), FadeIn(photo), FadeIn(credit), run_time=1.8)
    scene.pause("State: horizontal x, y, and heading psi. Fixed speed and altitude, with bounded steering. "
                "Photo illustrates an environmental-monitoring UAV, not the platform used in the paper. "
                "Photo source: " + source["source_url"] + ". Click to show the Dubins motion diagram.")

    curve = DubinsIllustration()
    segments = curve.segments()
    guide = segments.copy().set_stroke(color=MUTED, width=1.8, opacity=.65)
    title = _label("Forward motion with bounded turns", 22).move_to([3.6, 2.1, 0])
    caption = _label("Dubins path: left, straight, right", 21, CYAN).move_to([3.6, -2.1, 0])
    radius_formula = MathTex(r"R_{\min}=\frac{L}{\tan\delta_{\max}}", font_size=31).move_to([3.6, -2.85, 0])
    center = curve.start + UP * curve.radius
    radius_point, _ = curve.pose(curve.arc_length / 2)
    radius_guide = VGroup(
        Circle(radius=curve.radius, color=MUTED, stroke_width=1, stroke_opacity=.2).move_to(center),
        DashedLine(center, radius_point, color=MUTED, stroke_width=1.4),
        Dot(center, radius=.025, color=MUTED),
        MathTex(r"R_{\min}", font_size=23, color=MUTED).move_to([.8, -.45, 0]),
    )
    end, _ = curve.pose(curve.length)
    poses = VGroup(
        _label("Start", 17, MUTED).move_to(curve.start + DOWN * .55),
        Circle(radius=.055, color=INK, stroke_width=1.5).move_to(end),
        Arrow(end, end + RIGHT * .65, buff=0, color=MUTED, stroke_width=1.5),
        _label("Goal pose", 17, MUTED).move_to(end + UP * .48),
    )
    clock = ValueTracker(0)
    template = _uav_glyph().set_z_index(5)
    aircraft = template.copy().move_to(curve.start)

    def update_aircraft(mob):
        point, heading = curve.pose(clock.get_value())
        mob.become(template.copy().rotate(heading).move_to(point))

    aircraft.add_updater(update_aircraft)
    scene.play(Create(guide), FadeIn(title), FadeIn(caption), FadeIn(radius_formula),
               FadeIn(radius_guide), FadeIn(poses), FadeIn(aircraft), run_time=1.2)
    scene.pause("Analytic left-straight-right Dubins illustration. Circular arcs have radius R_min, "
                "and meet the straight segment tangentially. R_min follows from the paper's continuous planar model. "
                "The schematic is separate from the NMPC-generated Figure 4 trajectories. Dubins reference: "
                + DUBINS_SOURCE + ". Click to fly the left turn.")
    ends = (curve.arc_length, curve.arc_length + curve.straight, curve.length)
    previous = 0.0
    for segment, end_distance, description in zip(segments, ends, (
        "Left turn at the minimum radius. Click to fly the straight segment.",
        "Straight segment with zero steering. Click to fly the right turn.",
        "Right turn at the same minimum radius reaches the goal pose. The UAV follows the path tangent throughout.",
    )):
        segment.set_stroke(color=CYAN, width=3.5, opacity=1)
        # Proportional durations preserve constant forward speed between pauses.
        scene.play(Create(segment), clock.animate.set_value(end_distance), rate_func=linear,
                   run_time=9 * (end_distance - previous) / curve.length)
        scene.pause(description)
        previous = end_distance
    aircraft.clear_updaters()


def nmpc(scene):
    scene.page("Nonlinear model predictive control", "Paper: Cooperative tracking  /  CasADi + IPOPT")
    objective_title = _label("Optimize steering commands", 24).move_to([-3.2, 2.05, 0])
    optimizer = MathTex(r"\min_{\delta_0,\ldots,\delta_{N-1}} J", font_size=34).move_to([-3.2, 1.35, 0])
    cost = MathTex(r"J=\sum_{k=0}^{N-1}\left(w_p\|\mathbf p_k-\mathbf q^\star\|^2+w_u\delta_k^2\right)", font_size=32)
    if cost.width > 6.4:
        cost.scale_to_fit_width(6.4)
    cost.move_to([-3.2, .45, 0])
    cost_caption = _label("Waypoint error + steering effort", 21, MUTED).move_to([-3.2, -.35, 0])
    loop_title = _label("Receding-horizon loop", 24).move_to([3.7, 2.05, 0])
    scene.play(FadeIn(objective_title), Write(optimizer), Write(cost), FadeIn(cost_caption), FadeIn(loop_title), run_time=1.8)
    scene.pause("The paper's finite-horizon objective penalizes active-waypoint error and steering effort. "
                "The supplied implementation additionally regularizes steering changes. Click to add constraints and the measured state.")

    constraints = VGroup(
        MathTex(r"\mathbf s_{k+1}=f(\mathbf s_k,\delta_k)", font_size=30),
        MathTex(r"\mathbf s_0=\hat{\mathbf s},\quad |\delta_k|\leq\delta_{\max}", font_size=30),
    ).arrange(DOWN, buff=.3).move_to([-3.2, -1.35, 0])
    solver = _label("CasADi formulation, IPOPT solver", 20, MUTED).move_to([-3.2, -2.35, 0])
    steps = VGroup(*[_label(text, 23, CYAN if j == 2 else INK).move_to([3.7, 1.15 - .9*j, 0])
                     for j, text in enumerate(("1  Measure current state", "2  Optimize N future controls",
                                               "3  Apply first control only", "4  Measure again and repeat"))])
    arrows = VGroup(*[Arrow([3.7, .89 - .9*j, 0], [3.7, .52 - .9*j, 0],
                           buff=0, color=MUTED, stroke_width=1.5) for j in range(3)])
    scene.play(Write(constraints), FadeIn(solver), FadeIn(steps[0]), run_time=1.2)
    scene.pause("Anchor the predicted initial state to the measured state. Enforce nonlinear dynamics and the steering bound. "
                "The reduced state s contains x, y, and heading. Click to optimize the horizon.")
    scene.play(GrowArrow(arrows[0]), FadeIn(steps[1]), run_time=1.0)
    scene.pause("Solve for N future steering commands using the current active waypoint. Click to apply the first command.")
    scene.play(GrowArrow(arrows[1]), FadeIn(steps[2]), run_time=1.0)
    scene.pause("Execute only the first input of the optimized control sequence. Click to close the feedback loop.")
    return_path = VMobject(stroke_color=MUTED, stroke_width=1.5).set_points_as_corners(
        [[6.0, -1.55, 0], [6.5, -1.55, 0], [6.5, 1.15, 0]])
    return_tip = Arrow([6.5, 1.15, 0], [6.0, 1.15, 0], buff=0, color=MUTED, stroke_width=1.5)
    advance = _label("Advance the waypoint inside its acceptance radius", 24, CYAN).move_to([0, -3.0, 0])
    scene.play(GrowArrow(arrows[2]), FadeIn(steps[3]), Create(return_path), GrowArrow(return_tip), FadeIn(advance), run_time=1.2)
    scene.pause("Measure the updated state, solve again, and repeat. Advance the active assigned waypoint inside its acceptance radius. "
                "Each UAV solves its own NMPC problem. Independent planning does not guarantee collision avoidance.")
