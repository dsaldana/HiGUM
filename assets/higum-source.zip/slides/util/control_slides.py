"""Click-controlled explicit-Euler UAV dynamics and NMPC slides."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from manim import *
from manimpango import list_fonts

HERE = Path(__file__).resolve().parents[1]
INK = "#EDF2F7"
MUTED = "#9CADC2"
CYAN = "#62D9E8"
ORANGE = "#FFB15B"
FONT = next((f for f in ("Arial", "DejaVu Sans", "Liberation Sans") if f in list_fonts()), "sans-serif")
def _label(text, size=24, color=INK):
    return Text(text, font=FONT, font_size=size, color=color)


def dynamics_data():
    """Exact explicit-Euler updates of the displayed reduced planar model.

    Illustrative parameter values, distinct from the paper's flight experiments.
    Translation uses psi_t; the new heading applies to the following step.
    """
    dt, speed, length = 1.0, 10.0, 10.0
    controls = np.array([0., .35, .35, 0., -.35, -.35])
    states = [np.array([0., 0., np.pi / 12])]
    for delta in controls:
        x, y, psi = states[-1]
        states.append(states[-1] + dt * np.array([speed*np.cos(psi), speed*np.sin(psi), speed/length*np.tan(delta)]))
    states = np.array(states)
    increments = np.diff(states, axis=0)
    expected = dt * np.c_[speed*np.cos(states[:-1,2]), speed*np.sin(states[:-1,2]), speed/length*np.tan(controls)]
    assert np.allclose(increments, expected)
    assert np.allclose(np.linalg.norm(increments[:,:2], axis=1), dt*speed)
    return {"dt": dt, "speed": speed, "length": length, "steeringLimit": .45,
            "controls": controls.tolist(), "states": states.tolist(), "increments": increments.tolist()}


def _uav_glyph():
    """Editable top-view fixed-wing symbol, with its nose along +x."""
    outline = np.array([
        [.36, 0], [.18, .045], [.04, .045], [-.08, .32], [-.17, .32],
        [-.10, .04], [-.28, .035], [-.34, .14], [-.40, .14], [-.36, 0],
        [-.40, -.14], [-.34, -.14], [-.28, -.035], [-.10, -.04],
        [-.17, -.32], [-.08, -.32], [.04, -.045], [.18, -.045],
    ])
    return Polygon(*np.c_[outline, np.zeros(len(outline))],
                   fill_color=ORANGE, fill_opacity=1, stroke_color=INK, stroke_width=.8).scale(.75)


def uav_dynamics(scene):
    scene.page("Fixed-wing UAV dynamics", "Paper: Reduced planar model  /  Discrete-time state updates")
    equations = VGroup(
        MathTex(r"x_{t+1}=x_t+\Delta t\,v_0\cos\psi_t", font_size=33),
        MathTex(r"y_{t+1}=y_t+\Delta t\,v_0\sin\psi_t", font_size=33),
        MathTex(r"\psi_{t+1}=\psi_t+\Delta t\,\frac{v_0}{L}\tan\delta_t", font_size=33),
    ).arrange(DOWN, aligned_edge=LEFT, buff=.3).move_to([-3.2, 1.15, 0])
    constants = _label("Constant speed and altitude", 22, MUTED).move_to([-3.2, -.55, 0])
    steering = MathTex(r"|\delta_t|\leq\delta_{\max}", font_size=30).move_to([-3.2, -1.05, 0])
    photo = ImageMobject(str(HERE / "assets/monitoring_uav.jpg")).scale_to_fit_width(4.5)
    photo.move_to([-3.2, -2.15, 0])
    source = json.loads((HERE / "assets/monitoring_uav_source.json").read_text())
    name = source["short_caption"].split(" · ")[0]
    credit = _label(name + " · " + source["credit"], 11, MUTED).move_to([-3.2, -3.02, 0])
    scene.play(Write(equations), FadeIn(constants), FadeIn(steering), FadeIn(photo), FadeIn(credit), run_time=1.8)
    scene.pause("State: horizontal x, y, and heading psi. Fixed speed and altitude, with bounded steering. "
                "Photo illustrates an environmental-monitoring UAV, not the platform used in the paper. "
                "Photo source: " + source["source_url"] + ". Click to illustrate the three state-update equations.")

    model = dynamics_data()
    states = np.array(model["states"])
    low, high = states[:,:2].min(0), states[:,:2].max(0)
    scale = min(5.5 / np.ptp(states[:,0]), 2.7 / np.ptp(states[:,1]))
    def project(point):
        xy = (np.asarray(point)[:2] - (low+high)/2)*scale
        return np.r_[xy, 0] + np.array([3.65, -.05, 0])
    title = _label("Discrete updates of (x, y, ψ)", 23).move_to([3.6, 2.15, 0])
    params = _label("Δt = 1 s   ·   v₀ = 10 m/s   ·   L = 10 m", 17, MUTED).move_to([3.6, -2.6, 0])
    note = _label("Illustrative values · altitude fixed", 16, MUTED).move_to([3.6, -2.98, 0])
    origin = project(states[0])
    axes = VGroup(Arrow(origin,origin+RIGHT*.85,buff=0,color=MUTED,stroke_width=1.2),
                  Arrow(origin,origin+UP*.85,buff=0,color=MUTED,stroke_width=1.2),
                  _label("x",16,MUTED).move_to(origin+RIGHT*1.0),
                  _label("y",16,MUTED).move_to(origin+UP*1.0))
    aircraft = _uav_glyph().scale(.62).rotate(states[0,2]).move_to(origin)
    scene.play(FadeIn(title), FadeIn(params), FadeIn(note), FadeIn(axes), FadeIn(aircraft), run_time=1.0)
    scene.pause("Euler updates use the current heading psi_t for both x and y. Steering changes psi for the next step. "
                "Illustrative parameters: dt=1 s, v0=10 m/s, L=10 m, bounded steering. Click to apply the first step.")
    previous = VGroup()
    for j, delta in enumerate(model["controls"]):
        start, end = project(states[j]), project(states[j+1])
        corner = np.array([end[0],start[1],0])
        dx, dy, dpsi = model["increments"][j]
        components = VGroup(DashedLine(start,corner,color=CYAN,stroke_width=2),
                            DashedLine(corner,end,color=ORANGE,stroke_width=2),
                            _label("Δx",16,CYAN).move_to((start+corner)/2+DOWN*.2),
                            _label("Δy",16,ORANGE).move_to((corner+end)/2+RIGHT*.23),
                            Dot(start,radius=.035,color=INK),Dot(end,radius=.04,color=INK))
        step = _label(f"Step {j+1}/6   ·   δ = {delta:+.2f} rad",20,CYAN).move_to([3.6,1.65,0])
        numbers = _label(f"Δx = {dx:.1f} m   Δy = {dy:.1f} m   Δψ = {dpsi:+.2f} rad",17).move_to([3.6,-2.08,0])
        if len(previous):
            scene.play(FadeOut(previous),run_time=.25)
        equations[0:2].set_color(CYAN)
        equations[2].set_color(INK)
        scene.play(FadeIn(components),FadeIn(step),FadeIn(numbers),run_time=.5)
        path = Line(start,end,color=CYAN,stroke_width=3)
        scene.play(Create(path),aircraft.animate.move_to(end),run_time=1.8,rate_func=linear)
        equations[0:2].set_color(INK)
        equations[2].set_color(ORANGE)
        heading = VGroup(Arrow(end,end+.65*np.array([np.cos(states[j,2]),np.sin(states[j,2]),0]),buff=0,color=MUTED,stroke_width=1.3),
                         Arrow(end,end+.65*np.array([np.cos(states[j+1,2]),np.sin(states[j+1,2]),0]),buff=0,color=ORANGE,stroke_width=1.8))
        if abs(dpsi)>.001:
            heading.add(Arc(radius=.42,start_angle=states[j,2],angle=dpsi,arc_center=end,color=ORANGE,stroke_width=2))
        scene.play(FadeIn(heading),aircraft.animate.rotate(dpsi),run_time=1.0,rate_func=linear)
        previous=VGroup(components,step,numbers,heading)
        scene.pause(f"Step {j+1}: steering delta={delta:+.2f} rad. Translate using the old heading: "
                    f"dx={dx:.2f} m, dy={dy:.2f} m. Then update heading by dpsi={dpsi:+.3f} rad; "
                    "this new heading drives the next position update. "
                    + ("Click for the next step." if j<5 else "All six exact Euler steps are complete. Click to introduce NMPC."))
    equations.set_color(INK)


def nmpc(scene):
    scene.page("Nonlinear model predictive control", "Paper: Cooperative tracking  /  CasADi + IPOPT")
    objective_title = _label("Optimize steering commands", 24).move_to([-3.2, 2.05, 0])
    optimizer = MathTex(r"\min_{\delta_0,\ldots,\delta_{N-1}} J", font_size=34).move_to([-3.2, 1.35, 0])
    cost = MathTex(r"J=\sum_{k=0}^{N-1}\left(w_p\|\mathbf p_k-\mathbf q^\star\|^2+w_u\delta_k^2\right)", font_size=32)
    if cost.width > 6.4:
        cost.scale_to_fit_width(6.4)
    cost.move_to([-3.2, .45, 0])
    cost_caption = _label("Waypoint error + steering effort", 21, MUTED).move_to([-3.2, -.35, 0])
    loop_title = _label("Receding-horizon loop", 24).move_to([3.7, 2.05, 0])
    scene.play(FadeIn(objective_title), Write(optimizer), Write(cost), FadeIn(cost_caption), FadeIn(loop_title), run_time=1.8)
    scene.pause("The paper's finite-horizon objective penalizes active-waypoint error and steering effort. "
                "The supplied implementation additionally regularizes steering changes. Click to add constraints and the measured state.")

    constraints = VGroup(
        MathTex(r"\mathbf s_{k+1}=f(\mathbf s_k,\delta_k)", font_size=30),
        MathTex(r"\mathbf s_0=\hat{\mathbf s},\quad |\delta_k|\leq\delta_{\max}", font_size=30),
    ).arrange(DOWN, buff=.3).move_to([-3.2, -1.35, 0])
    solver = _label("CasADi formulation, IPOPT solver", 20, MUTED).move_to([-3.2, -2.35, 0])
    steps = VGroup(*[_label(text, 23, CYAN if j == 2 else INK).move_to([3.7, 1.15 - .9*j, 0])
                     for j, text in enumerate(("1  Measure current state", "2  Optimize N future controls",
                                               "3  Apply first control only", "4  Measure again and repeat"))])
    arrows = VGroup(*[Arrow([3.7, .89 - .9*j, 0], [3.7, .52 - .9*j, 0],
                           buff=0, color=MUTED, stroke_width=1.5) for j in range(3)])
    scene.play(Write(constraints), FadeIn(solver), FadeIn(steps[0]), run_time=1.2)
    scene.pause("Anchor the predicted initial state to the measured state. Enforce nonlinear dynamics and the steering bound. "
                "The reduced state s contains x, y, and heading. Click to optimize the horizon.")
    scene.play(GrowArrow(arrows[0]), FadeIn(steps[1]), run_time=1.0)
    scene.pause("Solve for N future steering commands using the current active waypoint. Click to apply the first command.")
    scene.play(GrowArrow(arrows[1]), FadeIn(steps[2]), run_time=1.0)
    scene.pause("Execute only the first input of the optimized control sequence. Click to close the feedback loop.")
    return_path = VMobject(stroke_color=MUTED, stroke_width=1.5).set_points_as_corners(
        [[6.0, -1.55, 0], [6.5, -1.55, 0], [6.5, 1.15, 0]])
    return_tip = Arrow([6.5, 1.15, 0], [6.0, 1.15, 0], buff=0, color=MUTED, stroke_width=1.5)
    advance = _label("Advance the waypoint inside its acceptance radius", 24, CYAN).move_to([0, -3.0, 0])
    scene.play(GrowArrow(arrows[2]), FadeIn(steps[3]), Create(return_path), GrowArrow(return_tip), FadeIn(advance), run_time=1.2)
    scene.pause("Measure the updated state, solve again, and repeat. Advance the active assigned waypoint inside its acceptance radius. "
                "Each UAV solves its own NMPC problem. Independent planning does not guarantee collision avoidance.")
