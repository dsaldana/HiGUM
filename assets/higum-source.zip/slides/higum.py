"""HiGUM paper presentation, built entirely from animated Manim geometry.

Run from this directory: manim-slides render -ql higum.py HiGUM
No paper figure image is loaded. Numeric assets are built by util/prepare_data.py.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np
from manim import *
from manim_slides import Slide
from manimpango import list_fonts
from util.thank_you import thank_you
from util.spatial_representations import spatial_representations
from util.control_slides import uav_dynamics, nmpc

HERE = Path(__file__).resolve().parent
BG = "#0B1423"
INK = "#EDF2F7"
MUTED = "#9CADC2"
CYAN = "#62D9E8"
ORANGE = "#FFB15B"
FLEET = ["#62D9E8", "#7FE0A0", "#C4A0FF", "#FFB15B", "#FF7FA5"]
PARTITIONS = FLEET + ["#F5DE72", "#8BAEFF", "#D9E1E8"]
HEAT = ["#4B427C", "#B65B94", "#F59067", "#FFD58A"]
FONT = next((f for f in ("Arial", "DejaVu Sans", "Liberation Sans") if f in list_fonts()), "sans-serif")
config.background_color = BG
PACE = float(os.environ.get("HIGUM_PACE", "1.6"))
if PACE <= 0:
    raise ValueError("HIGUM_PACE must be positive")


def label(text, size=25, color=INK, **kwargs):
    return Text(text, font=FONT, font_size=size, color=color, **kwargs)


def heat(value, lo, hi, log=False):
    if log:
        value, lo, hi = np.log10(np.maximum([value, lo, hi], 1e-12))
    t = float(np.clip((value - lo) / max(hi - lo, 1e-12), 0, 1))
    k = min(int(t * 3), 2)
    return interpolate_color(ManimColor(HEAT[k]), ManimColor(HEAT[k + 1]), t * 3 - k)


class Projection:
    """Fixed oblique 3-D view; one affine transform for points and ellipsoids.

    The WRF figure uses vertical exaggeration, as does the source paper.
    No geometric data are inferred from a raster figure.
    """
    def __init__(self, points, center=(-1.5, -0.15, 0), width=8.8,
                 height=4.4, vertical=1.0):
        self.world_center = (points.min(0) + points.max(0)) / 2
        self.matrix = np.array([[0.78, -0.62, 0], [0.25, 0.31, 0.94 * vertical]])
        flat = (points - self.world_center) @ self.matrix.T
        self.scale = min(width / np.ptp(flat[:, 0]), height / np.ptp(flat[:, 1]))
        self.offset = np.asarray(center)

    def __call__(self, points):
        points = np.asarray(points)
        flat = (points - self.world_center) @ self.matrix.T * self.scale
        return np.concatenate([flat, np.zeros((*flat.shape[:-1], 1))], axis=-1) + self.offset


def polyline(points, color, width=2, opacity=1):
    return VMobject(stroke_color=color, stroke_width=width,
                    stroke_opacity=opacity).set_points_as_corners(points)


def ellipsoid(mean, covariance, project, color, width=1.2):
    """Wireframe of the actual 2-standard-deviation covariance ellipsoid."""
    values, vectors = np.linalg.eigh(covariance)
    basis = vectors @ np.diag(2 * np.sqrt(np.maximum(values, 1e-10)))
    u = np.linspace(0, TAU, 49)
    rings = []
    for latitude in (-PI / 3, 0, PI / 3):
        sphere = np.array([np.cos(u) * np.cos(latitude),
                           np.sin(u) * np.cos(latitude), np.full_like(u, np.sin(latitude))]).T
        rings.append(polyline(project(mean + sphere @ basis.T), color, width, 0.8))
    for longitude in (0, PI / 3, 2 * PI / 3):
        sphere = np.array([np.cos(u) * np.cos(longitude),
                           np.cos(u) * np.sin(longitude), np.sin(u)]).T
        rings.append(polyline(project(mean + sphere @ basis.T), color, width, 0.8))
    return VGroup(*rings)


class HiGUM(Slide):
    """Nineteen topics, with presenter-controlled steps inside the animations."""
    def play(self, *animations, **kwargs):
        """Slow the rendered motion itself, consistently in native and HTML decks."""
        duration = kwargs.get("run_time")
        if duration is None:
            duration = max((a.get_run_time() if isinstance(a, Animation) else 1.0
                            for a in animations), default=1.0)
        kwargs["run_time"] = float(duration) * PACE
        return super().play(*animations, **kwargs)

    def setup(self):
        super().setup()
        data_path = HERE / "assets" / "higum_data.npz"
        if not data_path.exists():
            raise FileNotFoundError("Missing numeric assets. Run: python util/prepare_data.py")
        self.data = np.load(data_path, allow_pickle=False)
        improved_path = HERE / "assets" / "improved_plans.npz"
        self.improved = np.load(improved_path, allow_pickle=False) if improved_path.exists() else None
        self.topic = 0
        self.review_states = []

    def pause(self, note=""):
        self.wait(0.2)
        self.review_states.append({"time": float(self.renderer.time), "topic": self.topic, "note": note})
        self.next_slide(notes=note, auto_next=False)

    def page(self, title, source=""):
        if self.mobjects:
            self.play(*[FadeOut(m) for m in list(self.mobjects)], run_time=0.35)
        self.topic += 1
        heading = label(title, 35).to_corner(UL, buff=0.55)
        rule = Line([-6.55, 2.72, 0], [6.55, 2.72, 0], stroke_color=CYAN, stroke_width=1.5)
        footer = label(source or "HiGUM  /  LARS 2026", 14, MUTED).to_corner(DL, buff=0.35)
        number = label(f"{self.topic:02d}", 15, MUTED).to_corner(DR, buff=0.35)
        self.play(FadeIn(heading), Create(rule), FadeIn(footer), FadeIn(number), run_time=0.45)

    def paragraph(self, lines, x=4.6, top=1.6, size=23, color=INK, width=3.8):
        # Empty Text has no geometry and cannot reserve a predictable line gap.
        group = VGroup(*[label(s, size, color) if s else
                         Rectangle(width=.01, height=.16, stroke_opacity=0, fill_opacity=0)
                         for s in lines]).arrange(DOWN, buff=0.28, aligned_edge=LEFT)
        if group.width > width:
            group.scale_to_fit_width(width)
        group.move_to([x, top - group.height / 2, 0])
        return group

    def cloud(self, prefix, project, colored=True, max_points=650,
              radius=.017, opacity=.7, brightness=0):
        points = self.data[f"{prefix}_points"]
        c = self.data[f"{prefix}_concentration"]
        ids = np.linspace(0, len(points) - 1, min(len(points), max_points), dtype=int)
        dots = VGroup(*[Dot(project(points[i]), radius=radius,
                          color=interpolate_color(heat(c[i], c.min(), c.max(), prefix == "wrf"),
                                                  ManimColor(INK), brightness) if colored else MUTED,
                          fill_opacity=opacity, stroke_width=0) for i in ids])
        return dots, ids

    def gaussians(self, prefix, level, project, categorical=False):
        stem = f"{prefix}_level{level}"
        c = self.data[f"{prefix}_concentration"]
        means = self.data[f"{stem}_means"]
        covs = self.data[f"{stem}_covariances"]
        avg = self.data[f"{stem}_concentration"]
        return VGroup(*[ellipsoid(m, s, project,
                      PARTITIONS[j % len(PARTITIONS)] if categorical else heat(a, c.min(), c.max(), prefix == "wrf"))
                       for j, (m, s, a) in enumerate(zip(means, covs, avg))])

    def triad(self, origin=(-5.7, -2.25, 0)):
        o = np.array(origin)
        group = VGroup()
        for name, delta in [("x", [0.7, 0.22, 0]), ("y", [-0.5, 0.26, 0]), ("z", [0, 0.75, 0])]:
            delta = np.array(delta)
            group.add(Arrow(o, o + delta, buff=0, stroke_width=1.5, color=MUTED,
                            max_tip_length_to_length_ratio=0.15))
            group.add(label(name, 17, MUTED).move_to(o + delta * 1.25))
        return group

    def color_key(self, log=False):
        bars = VGroup(*[Line([3.4 + j * .075, -1.9, 0], [3.4 + (j + 1) * .075, -1.9, 0],
                            stroke_width=12, color=heat(j, 0, 39)) for j in range(40)])
        text = VGroup(label("low", 16, MUTED).move_to([3.5, -2.23, 0]),
                      label("high", 16, MUTED).move_to([6.2, -2.23, 0]),
                      label("Mean PM₂.₅ (µg/m³)", 16, MUTED).move_to([4.85, -1.35, 0]))
        if log:
            text.add(label("logarithmic color scale", 14, MUTED).move_to([4.85, -1.65, 0]))
        return VGroup(bars, text)

    def refine(self, old, new, run_time=1.3):
        # The stored children occur consecutively within each parent.
        if len(new) == 2 * len(old):
            wrappers = [VGroup(new[2*j], new[2*j+1]) for j in range(len(old))]
            self.play(*[ReplacementTransform(parent, children)
                        for parent, children in zip(list(old), wrappers)], run_time=run_time)
            # ReplacementTransform inserts the temporary wrappers into old's
            # hierarchy. Remove that complete hierarchy before owning the
            # same children through the canonical new group.
            self.remove(old, *wrappers)
            self.add(new)
        else:
            self.play(ReplacementTransform(old, new), run_time=run_time)
        return new

    def construct(self):
        self.title()
        self.motivation()
        spatial_representations(self)
        self.problem()
        self.figure_one()
        self.node_tuple()
        self.figure_two()
        self.em_split()
        self.figure_three()
        self.allocation()
        self.dynamics()
        self.mpc()
        for level, fleet in [(4, 3), (5, 5)]:
            self.trajectories(level, fleet)
        self.scalability()
        self.conclusion()
        thank_you(self)
        review_dir = HERE / "util" / "review"
        review_dir.mkdir(parents=True, exist_ok=True)
        (review_dir / "review_states.json").write_text(json.dumps(self.review_states, indent=2))

    def title(self):
        self.topic = 1
        title = label("HiGUM", 82, CYAN).move_to([-3.85, 1.75, 0])
        subtitle = self.paragraph(["A Hierarchical Gaussian Model", "for Cooperative Multi-UAV", "Smoke Monitoring"], x=-2.9, top=0.6, size=30, width=7)
        authors = label("David Saldaña   ·   Yunyao Li   ·   Diego Patiño", 20, MUTED).move_to([0, -2.45, 0])
        venue = label("LARS 2026", 20, CYAN).move_to([0, -3.25, 0])
        points = self.data["fig1_points"]
        project = Projection(points, center=(3.65, 0.3, 0), width=4.4, height=4.1)
        plume = self.gaussians("fig1", 4, project)
        # Use the universities' original artwork, scaled proportionally.
        lehigh = ImageMobject(str(HERE / "assets" / "lehigh_logo.png")).scale_to_fit_width(3.3)
        uta = ImageMobject(str(HERE / "assets" / "uta_logo.png")).scale_to_fit_width(3.6)
        for logo in (lehigh, uta):
            if logo.height > .75:
                logo.scale_to_fit_height(.75)
        lehigh.move_to([-5.75 + lehigh.width / 2, -3.25, 0])
        uta.move_to([5.75 - uta.width / 2, -3.25, 0])
        logos = Group(lehigh, uta)
        logo_sources = [json.loads((HERE / "assets" / f"{name}_logo_source.json").read_text())
                        for name in ("lehigh", "uta")]
        self.play(Write(title), FadeIn(subtitle, shift=UP*.15), FadeIn(logos), run_time=1.2)
        self.play(LaggedStart(*[Create(e) for e in plume], lag_ratio=.06), FadeIn(authors), FadeIn(venue), run_time=2.2)
        self.pause("Introduce HiGUM: one hierarchical representation connects smoke data to cooperative planning. "
                   + "University logo sources: " + "; ".join(source["source_url"] for source in logo_sources))

    def problem(self):
        self.page("Volumetric smoke monitoring", "Paper: Introduction and contributions")
        names = ["Smoke samples", "Gaussian hierarchy", "UAV plans"]
        centers = [-4.5, 0, 4.5]
        captions = ["Dense 3-D data", "Selectable resolution", "Independent MPC tracking"]
        headings = [label(name, 28).move_to([x, 1.8, 0]) for x, name in zip(centers, names)]
        details = [label(caption, 19, MUTED).move_to([x, -1.6, 0]) for x, caption in zip(centers, captions)]
        self.pause("Click to introduce the smoke samples.")
        rng = np.random.default_rng(4)
        cloud = VGroup(*[Dot([-4.5 + x, y, 0], radius=.035, color=ORANGE, fill_opacity=.75)
                        for x, y in rng.normal(size=(90, 2)) * [.65, .42]])
        tree = VGroup()
        for x0, y0, x1, y1 in [(0,.8,-.7,0),(0,.8,.7,0),(-.7,0,-1.1,-.7),(-.7,0,-.35,-.7),(.7,0,.35,-.7),(.7,0,1.1,-.7)]:
            tree.add(Line([x0,y0,0],[x1,y1,0], color=MUTED, stroke_width=2))
        for x,y in [(0,.8),(-.7,0),(.7,0),(-1.1,-.7),(-.35,-.7),(.35,-.7),(1.1,-.7)]:
            tree.add(Dot([x,y,0], radius=.08, color=CYAN))
        paths = VGroup(*[Ellipse(width=1.4, height=.75, color=col).rotate(a).move_to([4.5+dx,dy,0])
                        for dx,dy,a,col in [(-.4,.3,.4,FLEET[0]),(.45,.25,-.4,FLEET[1]),(0,-.4,0,FLEET[2])]])
        self.play(FadeIn(headings[0]), FadeIn(details[0]), FadeIn(cloud), run_time=1.5)
        self.pause("Dense 3-D samples preserve spatial detail. Click to introduce the Gaussian hierarchy.")
        self.play(Create(Arrow([-3,0,0],[-1.6,0,0], color=MUTED)),
                  FadeIn(headings[1]), FadeIn(details[1]), Create(tree), run_time=1.5)
        self.pause("The hierarchy offers selectable resolution. Click to introduce fleet planning.")
        self.play(Create(Arrow([1.6,0,0],[3,0,0], color=MUTED)),
                  FadeIn(headings[2]), FadeIn(details[2]), Create(paths), run_time=1.5)
        self.pause("UAVs independently track their allocated waypoint tours. Click for the main connection.")
        self.play(FadeIn(label("A compact interface between plume geometry and fleet planning", 27, CYAN).move_to([0,-2.6,0])))
        self.pause("A dense cloud preserves detail. The hierarchy offers a choice of planning resolution.")

    def motivation(self):
        self.page("Why monitor forest smoke?", "Motivation  /  Wildland-fire smoke monitoring")
        photo_path = HERE / "assets" / "forest_smoke.jpg"
        photo = ImageMobject(str(photo_path)).scale_to_fit_width(8.2)
        if photo.height > 4.8:
            photo.scale_to_fit_height(4.8)
        photo.move_to([-2.15, -.05, 0])
        points = self.paragraph(["Smoke extends beyond", "the fire perimeter.", "", "UAVs can measure", "its 3-D distribution.", "", "A fleet needs compact", "spatial planning targets."],
                                x=4.65, top=1.95, size=24, width=3.8)
        self.play(FadeIn(photo), run_time=1.5)
        self.pause("Forest smoke motivates spatially resolved monitoring. Photo credit and license are recorded in assets/forest_smoke_source.json.")
        self.play(FadeIn(points), run_time=1.2)
        photo_source = json.loads((HERE / "assets" / "forest_smoke_source.json").read_text())
        credit = photo_source.get("credit", photo_source.get("photographer", "Public-domain source photograph"))
        credit_text = label(photo_source.get("short_caption", "Forest wildfire and smoke") + "  ·  " + credit, 12, MUTED)
        if credit_text.width > 8.2:
            credit_text.scale_to_fit_width(8.2)
        credit_text.move_to([-2.15, -2.75, 0])
        self.add(credit_text)
        self.pause("The goal is to connect dense smoke data with cooperative UAV planning. Image source: " + photo_source.get("source_url", photo_source.get("url", "See asset metadata")))

    def figure_one(self):
        self.page("Three smoke sources, one hierarchy", "Figure 1  /  Synthetic merging plume  /  Animated from source data")
        project = Projection(self.data["fig1_points"], width=8.6, height=4.25)
        cloud, _ = self.cloud("fig1", project, radius=.025, opacity=1, brightness=.3)
        info = self.paragraph(["Three distinct sources", "merge downwind.", "", "One static snapshot"], size=24)
        self.play(LaggedStart(*[FadeIn(VGroup(*cloud[j:j+40])) for j in range(0,len(cloud),40)], lag_ratio=.07),
                  FadeIn(info), FadeIn(self.triad()), run_time=2)
        self.pause("Figure 1a. Reveal the synthetic point cloud. The reveal is a visual build, not a time evolution of smoke.")
        self.play(FadeOut(info), cloud.animate.set_opacity(.7))
        key = self.color_key()
        self.play(FadeIn(key))
        current = self.gaussians("fig1", 0, project)
        state = label("1 Gaussian", 34, CYAN).move_to([4.7,1.45,0])
        desc = self.paragraph(["The root summarizes", "the complete dataset."], top=.7, size=23)
        self.play(Create(current), FadeIn(state), FadeIn(desc), run_time=1.2)
        self.pause("Figure 1b. A single Gaussian is compact but misses the separate source geometry.")
        for level in range(1,5):
            new = self.gaussians("fig1", level, project)
            current = self.refine(current, new)
            self.play(Transform(state, label(f"{2**level} Gaussians",34,CYAN).move_to(state)), run_time=.25)
            if level == 2:
                self.play(Transform(desc, self.paragraph(["Four local summaries", "resolve more structure."],top=.7,size=23)))
                self.pause("Figure 1c. Four leaf partitions replace the root through recursive binary splits.")
        self.play(Transform(desc, self.paragraph(["Sixteen components", "follow the plume shape.", "", "Wireframes: 2σ surfaces"],top=.9,size=23)))
        self.pause("Figure 1d. Sixteen leaf partitions. Colors encode each subset's arithmetic mean concentration.")

    def node_tuple(self):
        self.page("What one Gaussian node stores", "Paper: Hierarchical Gaussian Model  /  Node tuple")
        formula = MathTex(r"\mathcal R_v=(\boldsymbol\mu_v,\boldsymbol\Sigma_v,\bar c_v)", font_size=46).move_to([0,1.8,0])
        ellipse = Ellipse(width=4.6,height=2.2,color=ORANGE,stroke_width=3).rotate(.35).move_to([-3,-.4,0])
        center = Dot(ellipse.get_center(),color=CYAN,radius=.075)
        self.play(Write(formula), Create(ellipse), FadeIn(center), run_time=1.3)
        mean = self.paragraph(["μ  Position centroid", "3 spatial coordinates"],x=3.5,top=.85,size=25,width=5)
        self.play(FadeIn(mean), Indicate(center,color=CYAN))
        self.pause("The Gaussian describes the distribution of point positions.")
        a = np.array([np.cos(.35),np.sin(.35),0])
        b = np.array([-np.sin(.35),np.cos(.35),0])
        axes = VGroup(Line(center.get_center()-2.3*a,center.get_center()+2.3*a,color=CYAN),
                      Line(center.get_center()-1.1*b,center.get_center()+1.1*b,color=CYAN))
        covariance = self.paragraph(["Σ  Orientation and extent", "6 independent covariance entries"],x=3.5,top=-.2,size=25,width=5)
        self.play(Create(axes), FadeIn(covariance))
        scalar = self.paragraph(["c̄  Mean PM₂.₅ concentration", "1 scalar attached to the node"],x=3.5,top=-1.25,size=25,width=5)
        self.play(ellipse.animate.set_fill(ORANGE,opacity=.22), FadeIn(scalar))
        self.add(label("10 stored scalars per node",24,CYAN).move_to([-3,-2.25,0]))
        self.pause("Concentration is summarized separately. It does not enter the spatial GMM fit. Covariance axes show two standard deviations.")

    def figure_two(self):
        self.page("Recursive binary partitioning", "Figure 2  /  Two-component, full-covariance GMM at each parent")
        project = Projection(self.data["fig2_points"],center=(-2.2,-.1,0),width=7.4,height=4.0)
        cloud, ids = self.cloud("fig2",project,colored=False,max_points=500)
        current = self.gaussians("fig2",0,project,categorical=True)
        self.play(FadeIn(cloud),Create(current))
        tree = VGroup(Dot([4.55,1.7,0],radius=.085,color=CYAN))
        self.add(tree)
        positions = {0:[np.array([4.55,1.7,0])]}
        state = label("Root: all samples",25,CYAN).move_to([4.55,-2.0,0])
        self.add(state)
        for depth in range(1,4):
            xs = np.linspace(3.0,6.1,2**depth)
            positions[depth] = [np.array([x,1.7-.88*depth,0]) for x in xs]
            branches = VGroup()
            for j,pos in enumerate(positions[depth]):
                branches.add(Line(positions[depth-1][j//2],pos,color=MUTED,stroke_width=1.6))
                branches.add(Dot(pos,radius=.06,color=PARTITIONS[j]))
            current = self.refine(current,self.gaussians("fig2",depth,project,categorical=True))
            labels = self.data[f"fig2_level{depth}_labels"]
            self.play(Create(branches),*[dot.animate.set_color(PARTITIONS[int(labels[i])]) for dot,i in zip(cloud,ids)],
                      Transform(state,label(f"{2**depth} disjoint subsets",25,CYAN).move_to(state)),run_time=.8)
            self.remove(branches)
            tree.add(branches)
            self.pause(f"Figure 2: {2**depth} leaf partitions. Colors distinguish subsets on this slide. Every child is fitted only within its parent dataset.")
        self.add(label("Partition colors",17,MUTED).move_to([-2.2,-2.55,0]))

    def em_split(self):
        self.page("One split: soft assignments, then disjoint children", "Paper: Partitioning the dataset  /  Expectation–Maximization")
        eq = MathTex(r"r_{iu}=\frac{\alpha_{u|v}\,p(\mathbf p_i\mid u)}{\sum_w\alpha_{w|v}\,p(\mathbf p_i\mid w)}",font_size=39).move_to([-3.0,1.35,0])
        self.play(Write(eq))
        steps = self.paragraph(["E step", "Estimate child probabilities", "", "M step", "Update weights, means, covariance"],x=3.25,top=1.8,size=25,width=5.3)
        self.play(FadeIn(steps))
        bars = VGroup()
        values = [.95,.8,.55,.35,.1]
        for j, r in enumerate(values):
            y = -.2-j*.38
            bars.add(Rectangle(width=3*r,height=.19,fill_color=CYAN,fill_opacity=1,stroke_width=0).move_to([-4.9+1.5*r,y,0]))
            bars.add(Rectangle(width=3*(1-r),height=.19,fill_color=ORANGE,fill_opacity=1,stroke_width=0).move_to([-4.9+3*r+1.5*(1-r),y,0]))
        self.play(LaggedStart(*[GrowFromEdge(b,LEFT) for b in bars],lag_ratio=.07))
        self.add(label("Illustrative responsibilities for five points",16,MUTED).move_to([-3.4,-2.25,0]))
        self.pause("Responsibility bars are illustrative probabilities, not measured concentration. EM iterates until log-likelihood convergence.")
        hard = VGroup()
        for j,r in enumerate(values):
            hard.add(Rectangle(width=3,height=.19,fill_color=CYAN if r>.5 else ORANGE,fill_opacity=1,stroke_width=0).move_to([-3.4,-.2-j*.38,0]))
        self.play(ReplacementTransform(bars,hard))
        self.play(FadeIn(self.paragraph(["After convergence", "Assign each point to argmax rᵢᵤ", "Recompute child statistics", "Reject undersized splits"],x=3.25,top=-.9,size=22,width=5.3)))
        self.pause("Hard assignments create disjoint child datasets. The arithmetic concentration mean is computed after partitioning.")

    def figure_three(self):
        self.page("WRF-FIRE smoke at selectable resolution", "Figure 3  /  Simulation time index 3  /  100 m grid spacing")
        points = self.data["wrf_points"]
        # The physical plume is shallow; this mirrors the paper's enlarged z view.
        project = Projection(points,center=(-1.7,-.1,0),width=8.2,height=4.1,vertical=6)
        cloud,_ = self.cloud("wrf",project,max_points=850,radius=.024,opacity=1)
        cloud.set_color(CYAN)
        note = self.paragraph(["Colorado wildfire simulation", "Retain concentration ≥ 10⁻⁶", "Every 50th valid voxel", "", "Cyan points: sample locations", "Vertical axis exaggerated"],size=22)
        self.pause("Click to reveal the WRF-FIRE smoke point cloud.")
        self.play(FadeIn(cloud),FadeIn(note),FadeIn(self.triad()),run_time=1.5)
        self.pause("Figure 3a. Extract a regular-grid smoke concentration point cloud. This is a static snapshot.")
        sample_label = label("Cyan points: sample locations",16,MUTED).move_to([-1.7,-2.72,0])
        self.play(FadeOut(note),cloud.animate.set_opacity(.75),FadeIn(self.color_key(log=True)),FadeIn(sample_label))
        state = label("Level 0  ·  1 node",29,CYAN).move_to([4.7,1.5,0])
        current = self.gaussians("wrf",0,project)
        self.play(Create(current),FadeIn(state))
        self.pause("The root contains the entire WRF-FIRE point cloud. Click to split it into two children.")
        for depth in range(1,6):
            current = self.refine(current,self.gaussians("wrf",depth,project),run_time=1.0)
            self.play(Transform(state,label(f"Level {depth}  ·  {2**depth} nodes",29,CYAN).move_to(state)),run_time=.2)
            self.pause(f"HGM level {depth} contains {2**depth} Gaussian ellipsoids. Click to refine the next level. Color represents mean PM2.5 on a logarithmic scale.")

    def plan_geometry(self,level,improved=False):
        stem=f"plans_level{level}"
        n=5 if level==5 else 3
        source=self.improved if improved and level==4 and self.improved is not None else self.data
        routes=[source[f"{stem}_route{j}"] for j in range(n)]
        trajectories=[source[f"{stem}_trajectory{j}"] for j in range(n)]
        depot=source[f"{stem}_depot"]
        # Keep each stored trajectory paired with its own route and fleet color.
        # All HGM centroids must have exactly one owner (the shared depot excepted).
        assigned=np.vstack([route[:-1] for route in routes])
        centroids=self.data[f"wrf_level{level}_means"][:,:2]
        matches=np.linalg.norm(assigned[:,None,:]-centroids[None,:,:],axis=-1)<1e-8
        assert np.all(matches.sum(0)==1) and np.all(matches.sum(1)==1)
        for route,trajectory in zip(routes,trajectories):
            assert np.allclose(route[-1],depot)
            assert np.allclose(trajectory[0,:2],depot)
        return routes,trajectories,depot

    def map_axes(self,trajectories,center=(-1.5,-.1,0),width=8.7,height=4.6):
        points=np.vstack([self.data["wrf_points"][:,:2],*[t[:,:2] for t in trajectories]])
        low=points.min(0)-1
        high=points.max(0)+1
        span=high-low
        scale=min(width/span[0],height/span[1])
        # Equal x/y scale preserves the trajectory curvature.
        def project(p):
            p=np.asarray(p)[...,:2]
            xy=(p-(low+high)/2)*scale
            return np.concatenate([xy,np.zeros((*xy.shape[:-1],1))],axis=-1)+np.array(center)
        axes=VGroup()
        for x in np.arange(np.ceil(low[0]/10)*10,high[0],10):
            axes.add(Line(project([x,low[1]]),project([x,high[1]]),stroke_color=MUTED,stroke_opacity=.12,stroke_width=1))
            axes.add(label(f"{(0 if abs(x)<1e-9 else x):g}",13,MUTED).move_to(project([x,low[1]])+DOWN*.18))
        for y in np.arange(np.ceil(low[1]/10)*10,high[1],10):
            axes.add(Line(project([low[0],y]),project([high[0],y]),stroke_color=MUTED,stroke_opacity=.12,stroke_width=1))
            axes.add(label(f"{(0 if abs(y)<1e-9 else y):g}",13,MUTED).move_to(project([low[0],y])+LEFT*.22))
        axes.add(label("x (km)",16,MUTED).move_to(project([(low[0]+high[0])/2,low[1]])+DOWN*.43))
        axes.add(label("y (km)",16,MUTED).rotate(PI/2).move_to(project([low[0],(low[1]+high[1])/2])+LEFT*.57))
        return project,axes

    def tour(self,route,project,color):
        vertices=project(np.vstack([route[-1],route]))
        return DashedVMobject(polyline(vertices,color,1.7,.55),num_dashes=max(20,len(route)*12),dashed_ratio=.5)

    def allocation(self):
        self.page("Centroids become fleet waypoints", "Paper: Cooperative planning  /  HGM level 4")
        routes,trajectories,depot=self.plan_geometry(4)
        project,axes=self.map_axes(trajectories)
        # Embed the top-view map into the ellipsoid helper's 3-D convention.
        means=self.data["wrf_level4_means"]
        covs=self.data["wrf_level4_covariances"]
        footprints=VGroup(*[ellipsoid(m,c,project,ORANGE,.8).set_stroke(opacity=.28) for m,c in zip(means,covs)])
        centroids=VGroup(*[Dot(project(m),radius=.055,color=INK) for m in means])
        text=self.paragraph(["1  Select hierarchy level", "2  Project centroids to (x, y)", "3  Allocate with k-means", "4  Order each cluster's tour"],x=4.65,top=1.65,size=22)
        self.play(FadeIn(axes),Create(footprints),FadeIn(text))
        self.play(FadeIn(centroids),run_time=.8)
        self.pause("The planner uses the horizontal projection of HGM centroids. Flights use a prescribed constant altitude.")
        assigned=VGroup(*[VGroup(*[Dot(project(q),radius=.065,color=FLEET[j]) for q in route[:-1]]) for j,route in enumerate(routes)])
        self.play(FadeOut(centroids),FadeIn(assigned))
        self.pause("K-means produces disjoint waypoint sets, one per UAV. Spatial clustering does not itself enforce balanced workloads.")
        tours=VGroup(*[self.tour(route,project,FLEET[j]) for j,route in enumerate(routes)])
        star=Star(n=5,outer_radius=.14,inner_radius=.06,color=INK,fill_opacity=1).move_to(project(depot))
        self.play(Create(tours),FadeIn(star),run_time=1.6)
        self.add(label("Common depot",18,MUTED).next_to(star,DOWN,buff=.12))
        self.pause("An exact depot-aware Hamiltonian cycle orders each small cluster. Dashed segments specify the intended waypoint tours.")

    def dynamics(self):
        uav_dynamics(self)

    def mpc(self):
        nmpc(self)

    def trajectories(self,level,n_uavs):
        replanned = level==4 and self.improved is not None
        source_note = ("Figure 4  /  Level 4 replanned demonstration  /  Same waypoint order and vehicle limits"
                       if replanned else "Figure 4  /  Original MPC trajectories  /  Top view, constant altitude")
        self.page(f"Level {level}: {2**level} waypoints, {n_uavs} UAVs", source_note)
        routes,trajectories,depot=self.plan_geometry(level,improved=replanned)
        assert n_uavs==len(routes)
        project,axes=self.map_axes(trajectories)
        raw=self.data["wrf_points"]
        ids=np.linspace(0,len(raw)-1,350,dtype=int)
        smoke=VGroup(*[Dot(project(raw[i]),radius=.012,color=MUTED,fill_opacity=.2,stroke_width=0) for i in ids])
        self.play(FadeIn(axes),FadeIn(smoke),run_time=.6)
        tours=VGroup(*[self.tour(route,project,FLEET[j]) for j,route in enumerate(routes)])
        # Hollow = assigned/pending; filled = accepted in this UAV's own route.
        waypoints=VGroup(*[VGroup(*[
            Circle(radius=.065,color=FLEET[j],stroke_width=1.8,fill_opacity=0).move_to(project(q))
            for q in route[:-1]]) for j,route in enumerate(routes)])
        depot_icon=Star(n=5,outer_radius=.13,inner_radius=.055,color=INK,fill_opacity=1).move_to(project(depot))
        legend=VGroup()
        progress=VGroup()
        for j,route in enumerate(routes):
            y=1.9-j*.43
            legend.add(Line([3.65,y,0],[4.05,y,0],color=FLEET[j],stroke_width=3))
            progress.add(label(f"UAV {j+1}  ·  0/{len(route)-1}",21,FLEET[j]).move_to([5.25,y,0]))
        legend.add(label("Assigned nodes accepted",17,MUTED).move_to([4.95,-.45,0]))
        legend.add(label("Dashed: assigned tour",17,MUTED).move_to([4.95,-.9,0]))
        legend.add(label("Solid: MPC trajectory",17,MUTED).move_to([4.95,-1.23,0]))
        legend.add(label("Ring: active target",17,MUTED).move_to([4.95,-1.56,0]))
        legend.add(label("Filled node: accepted",17,MUTED).move_to([4.95,-1.89,0]))
        legend.add(label("Target tolerance: 3 km",17,CYAN).move_to([4.95,-2.3,0]))
        if replanned:
            baseline_routes,baseline_trajectories,_=self.plan_geometry(level)
            old_length=sum(np.linalg.norm(np.diff(t[:,:2],axis=0),axis=1).sum() for t in baseline_trajectories)
            new_length=sum(np.linalg.norm(np.diff(t[:,:2],axis=0),axis=1).sum() for t in trajectories)
            legend.add(label("Route-aware MPC, N = 20",19,CYAN).move_to([4.95,.48,0]))
            legend.add(label(f"{new_length:.0f} km total (was {old_length:.0f} km)",19,INK).move_to([4.95,.12,0]))
        self.play(Create(tours),FadeIn(waypoints),FadeIn(depot_icon),FadeIn(legend),FadeIn(progress),run_time=1.1)
        self.pause(f"Figure 4, level {level}. Each color owns only its matching nodes. Ring and connector identify its active target. "
                   + ("This regenerated experiment uses route-aware MPC with horizon 20; it is distinct from the paper's original trajectory result. " if replanned else "")
                   + "Press next to start the MPC paths.")
        clock=ValueTracker(0)
        max_samples=max(len(t) for t in trajectories)
        glyphs=VGroup()
        trails=VGroup()
        target_indicators=VGroup()
        for j,(route,trajectory) in enumerate(zip(routes,trajectories)):
            coords=project(trajectory)
            # Replay run_mpc's actual acceptance tests at two-substep endpoints.
            # A new target always receives at least one control interval.
            accepted=[]
            start=2
            for target in route:
                candidates=np.arange(start,len(trajectory),2)
                hits=np.flatnonzero(np.linalg.norm(trajectory[candidates,:2]-target,axis=1)<3.)
                assert len(hits), f"MPC target missing: level {level}, UAV {j+1}"
                sample=int(candidates[hits[0]])
                accepted.append(sample)
                start=sample+2
            assert accepted[-1]==len(trajectory)-1
            accepted=np.asarray(accepted)
            color=FLEET[j]
            glyph=Triangle(stroke_width=1,stroke_color=BG,fill_color=color,fill_opacity=1).scale(.10)
            def pose(mob, trajectory=trajectory, coords=coords, color=color):
                # Shared sample index preserves simultaneous fleet playback.
                idx=min(clock.get_value(),len(trajectory)-1)
                k=min(int(idx),len(trajectory)-2)
                f=idx-k
                p=(1-f)*coords[k]+f*coords[k+1]
                yaw=trajectory[k,2]+f*np.arctan2(np.sin(trajectory[k+1,2]-trajectory[k,2]),np.cos(trajectory[k+1,2]-trajectory[k,2]))
                mob.become(Triangle(stroke_width=1,stroke_color=BG,fill_color=color,fill_opacity=1).scale(.10).rotate(yaw-PI/2).move_to(p))
            glyph.add_updater(pose)
            trail=VMobject(stroke_color=color,stroke_width=2.6)
            def trace(mob,coords=coords):
                idx=min(clock.get_value(),len(coords)-1)
                k=min(int(idx),len(coords)-2)
                tip=(1-(idx-k))*coords[k]+(idx-k)*coords[k+1]
                mob.set_points_as_corners(np.vstack([coords[:k+1],tip]))
            trail.add_updater(trace)
            ring=Circle(radius=.14,color=color,stroke_width=2.4)
            connector=Line(ORIGIN,RIGHT,stroke_color=color,stroke_width=1.1,stroke_opacity=.4)
            indicator=VGroup(ring,connector)
            def target_pose(mob, route=route, accepted=accepted, coords=coords):
                active=int(np.searchsorted(accepted,clock.get_value(),side="right"))
                if active==len(route):
                    mob.set_opacity(0)
                    return
                target=project(route[active])
                idx=min(clock.get_value(),len(coords)-1)
                k=min(int(idx),len(coords)-2)
                tip=(1-(idx-k))*coords[k]+(idx-k)*coords[k+1]
                mob[0].move_to(target)
                # Every pursuit target is this UAV's own waypoint, then depot.
                mob[1].put_start_and_end_on(tip,target)
            indicator.add_updater(target_pose)
            nodes=waypoints[j]
            def visits(mob, accepted=accepted):
                for node,sample in zip(mob,accepted[:-1]):
                    node.set_fill(opacity=1 if clock.get_value()>=sample else 0)
            nodes.add_updater(visits)
            status=progress[j]
            status.visited_count=-1
            def report(mob, accepted=accepted, j=j, route=route, color=color):
                count=min(int(np.searchsorted(accepted,clock.get_value(),side="right")),len(route)-1)
                if count!=mob.visited_count:
                    mob.become(label(f"UAV {j+1}  ·  {count}/{len(route)-1}",21,color).move_to(mob))
                    mob.visited_count=count
            status.add_updater(report)
            glyphs.add(glyph)
            trails.add(trail)
            target_indicators.add(indicator)
        self.add(trails,target_indicators,waypoints,depot_icon,glyphs)
        self.play(clock.animate.set_value(max_samples-1),run_time=18,rate_func=linear)
        for group in (glyphs,trails,target_indicators,waypoints,progress):
            group.clear_updaters(recursive=True)
        self.pause("Every colored node has now been accepted by its owner in route order. The paths can pass close to another UAV's nodes because of fixed-wing turning and the 3 km target tolerance; those nodes never become its targets. All UAVs return within the depot tolerance.")

    def scalability(self):
        self.page("Hierarchy construction at increasing depth", "Paper: HGM construction benchmark  /  Figure 5 experiment setup")
        values=VGroup(label("257,896",59,CYAN),label("valid smoke voxels",24,MUTED)).arrange(DOWN,buff=.2).move_to([-3.65,1.0,0])
        setup=self.paragraph(["Levels 1–15", "Five single-threaded runs", "Cumulative wall-clock time", "Full dataset for benchmarking"],x=3.1,top=1.9,size=27,width=5.5)
        self.play(FadeIn(values),FadeIn(setup))
        self.pause("The benchmark uses all valid voxels, unlike the every-50th-voxel point cloud used for the representation figures and planning.")
        line=Line([-5.8,-1.3,0],[5.8,-1.3,0],color=MUTED,stroke_width=2)
        ticks=VGroup(*[Dot([-5.8+j*11.6/14,-1.3,0],radius=.045,color=CYAN) for j in range(15)])
        self.play(Create(line),LaggedStart(*[FadeIn(d) for d in ticks],lag_ratio=.08),run_time=1.6)
        self.add(label("1",18,MUTED).move_to([-5.8,-1.68,0]),label("Hierarchy depth",20,MUTED).move_to([0,-1.68,0]),label("15",18,MUTED).move_to([5.8,-1.68,0]))
        self.play(FadeIn(label("Disjoint branches can be fitted concurrently",27,CYAN).move_to([0,-2.45,0])))
        self.pause("This slide shows the benchmark protocol, not a fabricated timing curve. Singleton nodes remain terminal. Parallel branches are a property of the hierarchy, while reported timings are single-threaded.")

    def conclusion(self):
        self.page("A hierarchy connects smoke data and UAV planning", "Paper: Conclusion and future work")
        findings=VGroup(*[label(s,30) for s in ["Compact plume summaries at selectable resolution", "Centroids supply cooperative planning targets", "MPC respects the reduced vehicle dynamics"]]).arrange(DOWN,buff=.45,aligned_edge=LEFT).to_edge(LEFT,buff=.8).shift(UP*.6)
        self.play(LaggedStart(*[FadeIn(m,shift=UP*.15) for m in findings],lag_ratio=.25),run_time=1.4)
        self.pause("The paper demonstrates an end-to-end pipeline on a WRF-FIRE smoke snapshot and fleets of three and five UAVs.")
        limitations=VGroup(label("Current scope",23,ORANGE),label("Static field · constant altitude · independent vehicle plans",23,MUTED),
                           label("Next steps",23,CYAN),label("Dynamic plumes, online measurements, collision and communication constraints",21,MUTED)).arrange(DOWN,aligned_edge=LEFT,buff=.2).to_edge(LEFT,buff=.8).shift(DOWN*1.75)
        self.play(FadeIn(limitations))
        self.pause("Future work: model temporal dynamics, assimilate new measurements, add fleet interaction constraints, and validate against observations.")
