"""Nonlinear MPC utilities for constant-speed planar fixed-wing planning.

The planner uses a kinematic Ackermann/bicycle approximation.  Its state is
``[x, y, yaw]`` and its only control is steering angle ``delta``; altitude and
forward speed are fixed.  CasADi formulates the nonlinear program and IPOPT
solves it at every receding-horizon step.
"""

import numpy as np
import matplotlib.pyplot as plt
import casadi as ca
def ackermann_mpc(N=40, dt=0.1, L=2.5, v0=1.0):
    """
    MPC for Ackermann vehicle with constant velocity.

    State:
        x = [x, y, theta]

    Control:
        u = [delta] (steering angle)

    Velocity is fixed to v0.

    Parameters
    ----------
    N : int
        Horizon length
    dt : float
        Time step
    L : float
        Effective wheelbase/turning-length parameter.  Together with the
        steering limit, it gives ``R_min = L / tan(delta_max)``.
    v0 : float
        Constant forward velocity

    Returns
    -------
    solver : CasADi NLP solver
        Apply steering limits when solving: pass ``delta_max`` into
        :func:`run_mpc`, which sets ``|delta_k| <= delta_max`` on all controls.
    """

    nx = 3   # [x, y, theta]
    nu = 1   # [delta]

    # Predicted states occupy N+1 knots; controls occupy the N intervals.
    X = ca.SX.sym('X', nx, N+1)
    U = ca.SX.sym('U', nu, N)

    # Runtime parameters: current state (3), active target (2), and previously
    # applied steering (1).  The latter preserves continuity between solves.
    P = ca.SX.sym('P', nx + 3)

    # Objective weights balance waypoint tracking, steering effort, and smoothness.
    w_p = 5.0    # position tracking (softer → less aggressive shortcuts / corners)
    w_u = 0.05   # control magnitude (keep steering moderate)
    w_du = 15.0  # steering rate smoothness within horizon
    w_u0 = 12.0  # match first control to previously applied steering (cross-step continuity)

    cost = 0
    g = []

    # Anchor the first predicted state to the measured/current state.
    g.append(X[:, 0] - P[:nx])

    target_xy = P[nx : nx + 2]
    delta_prev = P[nx + 2]

    # Direct multiple shooting: impose one discrete dynamics constraint per step.
    for k in range(N):

        x = X[0, k]
        y = X[1, k]
        theta = X[2, k]

        delta = U[0, k]

        # Constant-speed planar bicycle dynamics, discretized by forward Euler.
        x_dot = v0 * ca.cos(theta)
        y_dot = v0 * ca.sin(theta)
        theta_dot = v0 / L * ca.tan(delta)

        x_next = X[:, k] + dt * ca.vertcat(
            x_dot, y_dot, theta_dot
        )

        g.append(X[:, k+1] - x_next)

        pos_error = X[0:2, k] - target_xy
        cost += w_p * ca.dot(pos_error, pos_error)

        cost += w_u * delta**2

        # Penalize the first command relative to the command applied during the
        # previous MPC iteration, then penalize changes inside the horizon.
        if k == 0:
            du0 = U[0, 0] - delta_prev
            cost += w_u0 * du0**2
        else:
            du = U[:, k] - U[:, k-1]
            cost += w_du * ca.dot(du, du)
        if k >= 2:
            # A second finite difference suppresses rapid changes in steer rate.
            ddu = U[0, k] - 2 * U[0, k - 1] + U[0, k - 2]
            cost += 0.4 * w_du * ddu**2

    # CasADi vectorizes matrices in column-major order.  The bounds function
    # below must preserve this state-then-control ordering.
    OPT_variables = ca.vertcat(
        X.reshape((-1, 1)),
        U.reshape((-1, 1))
    )

    nlp = {
        'f': cost,
        'x': OPT_variables,
        'g': ca.vertcat(*g),
        'p': P
    }

    # Suppress IPOPT output because this solver is invoked many times per route.
    solver = ca.nlpsol(
        'solver',
        'ipopt',
        nlp,
        {
            'ipopt.print_level': 0,
            'print_time': 0
        }
    )

    return solver


def mpc_decision_bounds(N, nx, nu, delta_max, x_abs=1e9):
    """
    Box bounds for decision vector [vec(X); vec(U)] matching CasADi column-major
    stacking in ``ackermann_mpc``. States are loosely bounded; |delta| <= delta_max.
    """
    n_x = nx * (N + 1)
    n_u = nu * N
    lbx = np.concatenate([np.full(n_x, -x_abs), np.full(n_u, -delta_max)])
    ubx = np.concatenate([np.full(n_x, x_abs), np.full(n_u, delta_max)])
    return lbx, ubx


def run_mpc(
    solver,
    x0,
    waypoints,
    N=40,
    dt=0.05,
    L=2.5,
    v0=1.0,
    delta_max=None,
    max_iters_per_wp=60,
    wp_tol=0.1,
    max_steps=5000,
    return_status=False,
    integration_substeps=1,
):
    """
    Receding-horizon MPC tracking a sequence of waypoints in order.

    Parameters
    ----------
    delta_max : float, optional
        Max steering magnitude (rad), ``|delta| <= delta_max``. Default 30°.
    max_iters_per_wp : int
        MPC steps attempted per waypoint before moving on.
    wp_tol : float
        Stop pursuing a waypoint when ``||position - waypoint|| < wp_tol``.
    max_steps : int
        Safety cap on total simulation steps.
    integration_substeps : int
        Number of equal forward-Euler substeps used to apply each MPC control.
        Values greater than one preserve the MPC prediction interval while
        reducing the executed trajectory's integration step.
    return_status : bool
        When true, also return one Boolean reach flag per waypoint.

    Returns
    -------
    traj : ndarray, shape (T, 3)
        Executed trajectory over time.  If ``return_status`` is true, the
        return value is ``(traj, reached_waypoints)``.
    """
    if delta_max is None:
        delta_max = np.deg2rad(30.0)

    state = x0.copy()
    traj = [state.copy()]
    reached_waypoints = []
    delta_prev = 0.0

    nx, nu = 3, 1
    lbx, ubx = mpc_decision_bounds(N, nx, nu, delta_max)
    total = 0

    # Process the ordered targets sequentially, as in a waypoint state machine.
    for wp in waypoints:
        target = np.asarray(wp, dtype=float)
        reached = False
        for _ in range(max_iters_per_wp):
            if total >= max_steps:
                result = np.array(traj)
                return (result, reached_waypoints) if return_status else result

            # Solve a fresh finite-horizon problem around the current state and
            # apply only its first control (the receding-horizon principle).
            p = np.concatenate([state, target, [delta_prev]])
            sol = solver(p=p, lbx=lbx, ubx=ubx, lbg=0, ubg=0)
            sol_x = sol["x"].full().flatten()
            offset = nx * (N + 1)
            u0 = sol_x[offset : offset + nu]
            delta = float(np.clip(u0[0], -delta_max, delta_max))
            delta_prev = delta

            # Smaller execution substeps give a visually and numerically smoother
            # trajectory without changing the MPC prediction interval.
            substep_dt = dt / integration_substeps
            for _ in range(integration_substeps):
                x, y, theta = state
                x_dot = v0 * np.cos(theta)
                y_dot = v0 * np.sin(theta)
                theta_dot = v0 / L * np.tan(delta)
                state = state + substep_dt * np.array(
                    [x_dot, y_dot, theta_dot]
                )
                traj.append(state.copy())
            total += 1

            if np.linalg.norm(state[:2] - target) < wp_tol:
                reached = True
                break
        reached_waypoints.append(reached)

    result = np.array(traj)
    return (result, reached_waypoints) if return_status else result


def plot_trajectory(traj, waypoints):
    """Display an MPC trajectory, waypoint markers, and sampled headings."""
    plt.figure(figsize=(8, 6))

    plt.plot(traj[:, 0], traj[:, 1], label="Trajectory")

    wps = np.array(waypoints)
    plt.scatter(wps[:, 0], wps[:, 1], color='red', label="Waypoints")

    # Draw approximately twenty heading arrows without allowing a zero stride.
    arrow_stride = max(1, len(traj) // 20)
    for i in range(0, len(traj), arrow_stride):
        x, y, theta = traj[i]
        plt.arrow(x, y, 0.3*np.cos(theta), 0.3*np.sin(theta),
                  head_width=0.1, alpha=0.5)

    plt.xlabel("x")
    plt.ylabel("y")
    plt.title("Ackermann MPC Trajectory")
    plt.axis("equal")
    plt.grid(True)
    plt.legend()
    plt.show()


if __name__ == "__main__":
    # Small interactive example used to inspect the MPC independently.
    # Initial state: x, y, yaw (speed is the fixed model parameter ``v0``).
    x0 = np.array([0.0, 0.0, 0.0])

    # Waypoints (fixed sequence)
    waypoints = [
        [2, 2],
        [4, 0],
        [0,0]
    ]

    N = 20
    dt = 0.1
    L = 1.5
    v0 = 1
    delta_max = np.deg2rad(60.0)
    
    solver = ackermann_mpc(N=N, dt=dt, L=L, v0=v0)
    traj = run_mpc(solver, x0, waypoints, N=N, dt=dt, L=L, v0=v0, delta_max=delta_max)

    plot_trajectory(traj, waypoints)
