#!/usr/bin/env python3
"""Extract WRF-FIRE smoke data and plot two HGM resolutions.

The array-to-coordinate convention and default sampling reproduce the
``octree2.ipynb`` experiment.  Coordinates are expressed in kilometers and the
scalar array values are treated as PM2.5 concentration.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import cm
from matplotlib.colors import LogNorm
from matplotlib.ticker import MaxNLocator
from sklearn.mixture import GaussianMixture

from generate_single_ellipsoid import ellipsoid_wireframe


def extract_point_cloud(
    smoke_path: Path, time_index: int = 3, skip: int = 50,
    threshold: float = 1e-6,
) -> tuple[np.ndarray, np.ndarray]:
    """Convert one WRF-FIRE time slice into positions and concentrations.

    Invalid sentinels, zeros, and values below ``threshold`` are removed before
    taking every ``skip``-th valid voxel.  Memory mapping avoids loading every
    simulation time step into RAM.
    """
    smoke = np.load(smoke_path, mmap_mode="r")
    values_3d = smoke[time_index]
    mask = (
        (values_3d != -9999.0)
        & (values_3d != 0.0)
        & (values_3d >= threshold)
    )
    # Generate integer voxel coordinates only for the selected 3-D time slice.
    axis_0, axis_1, axis_2 = np.indices(values_3d.shape)
    # The notebook maps the array indices to x=axis_1, y=axis_2, z=axis_0.
    points = 0.1 * np.column_stack(
        [axis_1[mask][::skip], axis_2[mask][::skip], axis_0[mask][::skip]]
    ).astype(float)
    concentration = np.asarray(values_3d[mask][::skip], dtype=float)
    return points, concentration


def split_level(
    points: np.ndarray, partitions: list[np.ndarray], seed: int,
) -> list[np.ndarray]:
    """Split every node with a two-component full-covariance GMM."""
    children: list[np.ndarray] = []
    for number, indices in enumerate(partitions):
        model = GaussianMixture(
            n_components=2,
            covariance_type="full",
            reg_covar=1e-6,
            random_state=seed + number,
        )
        # Child nodes retain global indices so concentrations need not be copied.
        labels = model.fit_predict(points[indices])
        children.extend(indices[labels == component] for component in range(2))
    return children


def hierarchy(points: np.ndarray, seed: int) -> dict[int, list[np.ndarray]]:
    """Return the complete binary levels through depth five."""
    partitions = [np.arange(len(points))]
    levels = {1: partitions}
    for _ in range(5):
        partitions = split_level(points, partitions, seed)
        levels[len(partitions)] = partitions
    return levels


def configure_axis(ax, points: np.ndarray) -> None:
    """Apply shared limits, grid styling, units, and viewing angle to a panel."""
    point_min = points.min(axis=0)
    point_max = points.max(axis=0)
    padding = np.maximum(0.02 * (point_max - point_min), 0.5)
    ax.set_xlim(point_min[0] - padding[0], point_max[0] + padding[0])
    ax.set_ylim(point_min[1] - padding[1], point_max[1] + padding[1])
    ax.set_zlim(point_min[2] - padding[2], point_max[2] + padding[2])
    # Preserve the numerical coordinate limits but enlarge the displayed
    # vertical dimension so the shallow plume structure remains legible.
    ax.set_box_aspect((1.12, 1.32, 0.82), zoom=0.93)
    ax.view_init(elev=25, azim=-58)
    ax.set_xlabel(r"$x$ (km)", fontsize=5.5, labelpad=-1)
    ax.set_ylabel(r"$y$ (km)", fontsize=5.5, labelpad=-1)
    ax.set_zlabel(r"$z$ (km)", fontsize=5.5, labelpad=-2)
    ax.xaxis.set_major_locator(MaxNLocator(4, integer=True))
    ax.yaxis.set_major_locator(MaxNLocator(4, integer=True))
    ax.zaxis.set_major_locator(MaxNLocator(4, integer=True))
    ax.tick_params(axis="both", which="major", labelsize=4.5, pad=-1, length=2)
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis.pane.set_facecolor((0.96, 0.96, 0.96, 0.30))
        axis.pane.set_edgecolor((0.35, 0.35, 0.35, 0.75))
        axis._axinfo["grid"].update(
            {"color": (0.55, 0.55, 0.55, 0.45), "linewidth": 0.35}
        )
    ax.grid(True)


def draw_panel(
    ax, points: np.ndarray, concentration: np.ndarray,
    partitions: list[np.ndarray] | None, norm: LogNorm, cmap,
) -> None:
    """Draw the smoke samples and optional Gaussian ellipsoids for one level."""
    ax.scatter(
        points[:, 0], points[:, 1], points[:, 2],
        c=concentration, cmap=cmap, norm=norm,
        s=1.5, alpha=0.30, linewidths=0, depthshade=False,
    )
    if partitions is not None:
        for indices in partitions:
            subset = points[indices]
            mean = subset.mean(axis=0)
            # Regularization prevents degenerate ellipsoids for very thin nodes.
            covariance = np.cov(subset, rowvar=False) + np.eye(3) * 1e-6
            average = float(concentration[indices].mean())
            x_ell, y_ell, z_ell = ellipsoid_wireframe(
                mean, covariance, n_std=2.0, n_azimuth=32, n_polar=16
            )
            color = cmap(norm(average))
            ax.plot_wireframe(
                x_ell, y_ell, z_ell,
                rstride=2, cstride=2, color=color,
                linewidth=0.42 if len(partitions) == 32 else 0.65,
                alpha=0.88,
            )
    configure_axis(ax, points)


def create_figure(
    smoke_path: Path, output: Path, time_index: int, skip: int, seed: int,
) -> None:
    """Build and export the point-cloud, level-2, and level-5 comparison."""
    points, concentration = extract_point_cloud(smoke_path, time_index, skip)
    levels = hierarchy(points, seed)
    norm = LogNorm(vmin=concentration.min(), vmax=concentration.max())
    cmap = plt.get_cmap("inferno")

    plt.rcParams.update({"font.family": "serif", "font.size": 7})
    fig = plt.figure(figsize=(7.16, 2.42))
    panels = (
        ("(a) WRF-FIRE point cloud", None),
        ("(b) Level 2: 4 ellipsoids", levels[4]),
        ("(c) Level 5: 32 ellipsoids", levels[32]),
    )
    width = 1.0 / 3.0
    for panel, (title, partitions) in enumerate(panels):
        left = panel * width
        ax = fig.add_axes([left, 0.18, width, 0.73], projection="3d")
        draw_panel(ax, points, concentration, partitions, norm, cmap)
        fig.text(left + width / 2, 0.96, title, ha="center", va="top", fontsize=7)

    colorbar_axis = fig.add_axes([0.16, 0.055, 0.68, 0.022])
    colorbar = fig.colorbar(
        cm.ScalarMappable(norm=norm, cmap=cmap),
        cax=colorbar_axis, orientation="horizontal",
    )
    colorbar.set_label(
        r"WRF-FIRE PM$_{2.5}$ concentration ($\mu$g m$^{-3}$)",
        fontsize=6.5,
        labelpad=1,
    )
    colorbar.ax.xaxis.set_label_position("top")
    colorbar.ax.tick_params(labelsize=5.5, pad=1, length=2)

    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, format="pdf", bbox_inches="tight", pad_inches=0.01)
    plt.close(fig)


def parse_args() -> argparse.Namespace:
    """Parse WRF-FIRE input, sampling, output, and reproducibility options."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--smoke", type=Path, default=Path("code/fire_smoke_data.npy"))
    parser.add_argument(
        "--output", type=Path,
        default=Path("output/pdf/wrf_fire_hgm_hierarchy.pdf"),
    )
    parser.add_argument("--time-index", type=int, default=3)
    parser.add_argument("--skip", type=int, default=50)
    parser.add_argument("--seed", type=int, default=0)
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    create_figure(args.smoke, args.output, args.time_index, args.skip, args.seed)
