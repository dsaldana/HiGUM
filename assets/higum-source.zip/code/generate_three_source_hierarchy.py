#!/usr/bin/env python3
"""Generate a merging three-source plume and its HGM comparison figure.

The synthetic sources begin at different crosswind coordinates, converge to a
shared downwind path, and retain separate concentration strengths.  The same
binary partitioning functions used by the one-source example build the HGM.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import cm
from matplotlib.colors import Normalize

from generate_hierarchical_partitions import hierarchy_levels
from generate_single_ellipsoid import ellipsoid_wireframe


def generate_three_source_plume(
    points_per_source: int, seed: int
) -> tuple[np.ndarray, np.ndarray]:
    """Generate three rising plumes that merge into one downwind plume."""
    rng = np.random.default_rng(seed)
    # Source offsets and relative emission strengths create visibly distinct
    # near-source lobes before the smoke combines downstream.
    source_y = np.array([-3.0, 0.0, 3.0])
    source_strength = np.array([1.00, 0.86, 0.94])
    all_points: list[np.ndarray] = []
    all_concentrations: list[np.ndarray] = []

    for source, (initial_y, strength) in enumerate(
        zip(source_y, source_strength)
    ):
        progress = rng.beta(1.15, 1.30, points_per_source)

        # Separate near-source centerlines converge toward a shared downwind
        # trajectory as progress approaches one.
        convergence = (1.0 - progress) ** 1.65
        centerline = np.column_stack(
            [
                7.5 * progress,
                initial_y * convergence
                + 0.28 * np.sin(1.4 * np.pi * progress),
                0.25
                + 2.5 * progress
                + 0.35 * np.sin(np.pi * progress)
                + 0.08 * source,
            ]
        )

        # Independent longitudinal, crosswind, and vertical noise approximates
        # turbulent dispersion whose width increases with travel distance.
        spread = 0.07 + 0.44 * progress
        along = rng.normal(0.0, 0.10 + 0.14 * progress)
        crosswind = rng.normal(0.0, spread)
        vertical = rng.normal(0.0, 0.58 * spread)
        points = centerline + np.column_stack([along, crosswind, vertical])

        normalized_radius = (crosswind / spread) ** 2
        normalized_radius += (vertical / (0.58 * spread)) ** 2
        concentration = 7.0 + 38.0 * strength * np.exp(-1.20 * progress)
        concentration *= np.exp(-0.15 * normalized_radius)
        concentration += rng.normal(0.0, 1.0, points_per_source)

        all_points.append(points)
        all_concentrations.append(np.clip(concentration, 0.0, None))

    return np.vstack(all_points), np.concatenate(all_concentrations)


def draw_panel(
    ax,
    points: np.ndarray,
    concentration: np.ndarray,
    partitions: list[np.ndarray] | None,
    norm: Normalize,
    cmap,
) -> None:
    """Draw the raw dataset and, when supplied, its partition ellipsoids."""
    ax.scatter(
        points[:, 0],
        points[:, 1],
        points[:, 2],
        c=concentration,
        cmap=cmap,
        norm=norm,
        s=3.2,
        alpha=0.43,
        linewidths=0,
        depthshade=False,
    )

    if partitions is not None:
        for indices in partitions:
            partition_points = points[indices]
            mean = partition_points.mean(axis=0)
            covariance = np.cov(partition_points, rowvar=False)
            average = concentration[indices].mean()
            x_ell, y_ell, z_ell = ellipsoid_wireframe(
                mean,
                covariance,
                n_std=2.0,
                n_azimuth=36,
                n_polar=18,
            )
            color = cmap(norm(average))
            ax.plot_wireframe(
                x_ell,
                y_ell,
                z_ell,
                rstride=2,
                cstride=2,
                color=color,
                linewidth=0.52,
                alpha=0.9,
            )
            ax.scatter(*mean, color=color, marker="x", s=12, linewidth=0.8)

    point_min = points.min(axis=0)
    point_max = points.max(axis=0)
    padding = 0.03 * (point_max - point_min)
    ax.set_xlim(point_min[0] - padding[0], point_max[0] + padding[0])
    ax.set_ylim(point_min[1] - padding[1], point_max[1] + padding[1])
    ax.set_zlim(point_min[2] - padding[2], point_max[2] + padding[2])
    ax.set_box_aspect(np.ptp(points, axis=0), zoom=1.28)
    ax.view_init(elev=38, azim=-55)
    ax.set_axis_off()


def create_figure(output: Path, points_per_source: int, seed: int) -> None:
    """Create the four-panel, two-column hierarchy figure."""
    points, concentration = generate_three_source_plume(
        points_per_source, seed
    )
    levels = hierarchy_levels(points, seed)
    # A partition is represented by indices into the common point-cloud arrays.
    root = [np.arange(len(points))]
    norm = Normalize(concentration.min(), concentration.max())
    cmap = plt.get_cmap("inferno")

    plt.rcParams.update({"font.family": "serif", "font.size": 7})
    fig = plt.figure(figsize=(7.16, 2.10))
    panels = (
        ("(a) Dataset", None),
        ("(b) 1 partition", root),
        ("(c) 4 partitions", levels[4]),
        ("(d) 16 partitions", levels[16]),
    )
    panel_width = 0.25
    for panel_number, (title, partitions) in enumerate(panels):
        left = panel_number * panel_width
        ax = fig.add_axes([left, 0.11, panel_width, 0.84], projection="3d")
        draw_panel(ax, points, concentration, partitions, norm, cmap)
        fig.text(
            left + panel_width / 2,
            0.91,
            title,
            ha="center",
            va="top",
            fontsize=7,
        )

    colorbar_axis = fig.add_axes([0.14, 0.07, 0.72, 0.025])
    colorbar = fig.colorbar(
        cm.ScalarMappable(norm=norm, cmap=cmap),
        cax=colorbar_axis,
        orientation="horizontal",
    )
    colorbar.set_label(
        r"Concentration ($\mu$g m$^{-3}$)", fontsize=6.5, labelpad=1
    )
    colorbar.ax.xaxis.set_label_position("top")
    colorbar.ax.tick_params(labelsize=6, pad=1, length=2)

    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, format="pdf", bbox_inches="tight", pad_inches=0.01)
    plt.close(fig)


def parse_args() -> argparse.Namespace:
    """Parse output, per-source sample count, and random seed."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("output/pdf/three_source_gmm_hierarchy.pdf"),
    )
    parser.add_argument("--points-per-source", type=int, default=300)
    parser.add_argument("--seed", type=int, default=23)
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    create_figure(args.output, args.points_per_source, args.seed)
