#!/usr/bin/env python3
"""Generate Fig. 1: a synthetic smoke plume and one Gaussian ellipsoid.

The point coordinates model a curved, rising, and widening plume.  A separate
scalar value models PM2.5 concentration at every point.  The Gaussian is fitted
to positions only; concentration controls point color and the ellipsoid is
colored by the ordinary mean concentration.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import cm
from matplotlib.colors import Normalize
from matplotlib.transforms import Bbox


def ellipsoid_wireframe(
    mean: np.ndarray,
    covariance: np.ndarray,
    n_std: float = 2.0,
    n_azimuth: int = 48,
    n_polar: int = 24,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return Cartesian coordinates for a covariance-ellipsoid wireframe.

    The covariance eigenvectors define the principal directions and
    ``n_std * sqrt(eigenvalue)`` defines each semi-axis length.
    """
    # ``eigh`` is used because covariance matrices are real and symmetric.
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)
    radii = n_std * np.sqrt(np.maximum(eigenvalues, 0.0))
    azimuth = np.linspace(0.0, 2.0 * np.pi, n_azimuth)
    polar = np.linspace(0.0, np.pi, n_polar)
    sphere = np.stack(
        [
            np.outer(np.cos(azimuth), np.sin(polar)),
            np.outer(np.sin(azimuth), np.sin(polar)),
            np.outer(np.ones_like(azimuth), np.cos(polar)),
        ],
        axis=-1,
    )
    # Scale a unit sphere along its axes, rotate it into the covariance basis,
    # and translate it to the Gaussian mean.
    ellipsoid = sphere @ np.diag(radii) @ eigenvectors.T + mean
    return ellipsoid[..., 0], ellipsoid[..., 1], ellipsoid[..., 2]


def generate_point_cloud(
    n_points: int, seed: int
) -> tuple[np.ndarray, np.ndarray]:
    """Create a curved, widening smoke plume with scalar concentrations."""
    rng = np.random.default_rng(seed)
    # The beta distribution places samples along the entire plume while still
    # producing a denser body than a uniform longitudinal distribution.
    progress = rng.beta(1.2, 1.35, n_points)

    # A bent, rising centerline approximates advection and plume rise.
    centerline = np.column_stack(
        [
            7.0 * (progress - 0.5),
            0.8 * np.sin(1.5 * np.pi * progress),
            0.3 + 2.7 * progress + 0.55 * np.sin(np.pi * progress),
        ]
    )

    # Turbulent dispersion widens the plume away from its source.
    spread = 0.12 + 0.65 * progress
    radial_y = rng.normal(0.0, spread)
    radial_z = rng.normal(0.0, 0.62 * spread)
    along_plume = rng.normal(0.0, 0.12 + 0.16 * progress)
    points = centerline + np.column_stack(
        [along_plume, radial_y, radial_z]
    )

    # Concentration is highest near the source and plume centerline.
    normalized_radius = (radial_y / spread) ** 2
    normalized_radius += (radial_z / (0.62 * spread)) ** 2
    concentration = 8.0 + 34.0 * np.exp(-1.25 * progress)
    concentration *= np.exp(-0.16 * normalized_radius)
    concentration += rng.normal(0.0, 1.2, n_points)
    return points, np.clip(concentration, 0.0, None)


def create_figure(output: Path, n_points: int, seed: int) -> None:
    """Fit one spatial Gaussian and save the publication-ready vector PDF."""
    points, concentration = generate_point_cloud(n_points, seed)
    mean = points.mean(axis=0)
    covariance = np.cov(points, rowvar=False)
    x_ell, y_ell, z_ell = ellipsoid_wireframe(mean, covariance)

    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.size": 8,
            "axes.labelsize": 8,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
        }
    )
    fig = plt.figure(figsize=(3.45, 1.45))
    ax = fig.add_subplot(111, projection="3d")
    ax.set_position([-0.13, -0.18, 1.36, 1.25])

    # All objects share one normalization so equal concentrations have equal
    # colors in the point cloud, ellipsoid, centroid, and color bar.
    norm = Normalize(concentration.min(), concentration.max())
    cmap = plt.get_cmap("inferno")
    average_color = cmap(norm(concentration.mean()))
    ax.scatter(
        points[:, 0],
        points[:, 1],
        points[:, 2],
        c=concentration,
        cmap=cmap,
        norm=norm,
        s=5,
        alpha=0.58,
        linewidths=0,
        depthshade=False,
    )
    ax.plot_wireframe(
        x_ell,
        y_ell,
        z_ell,
        rstride=2,
        cstride=2,
        color=average_color,
        linewidth=0.55,
        alpha=0.85,
    )
    ax.scatter(*mean, color=average_color, marker="x", s=28, linewidth=1.2)

    ax.set_xlabel("")
    ax.set_ylabel("")
    ax.set_zlabel("")
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_zticks([])
    ax.view_init(elev=22, azim=-58)
    ax.set_box_aspect(np.ptp(points, axis=0), zoom=1.40)
    ax.grid(False)
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis.pane.fill = False
        axis.pane.set_edgecolor("0.85")
    ax.set_axis_off()

    # A separate 3-D inset displays the orthogonal Cartesian basis without
    # overlapping the plume or requiring the full main-axis bounding box.
    triad_ax = fig.add_axes([0.29, 0.20, 0.16, 0.20], projection="3d")
    triad_ax.set_axis_off()
    triad_ax.set_xlim(0.0, 1.25)
    triad_ax.set_ylim(0.0, 1.25)
    triad_ax.set_zlim(0.0, 1.25)
    triad_ax.set_box_aspect((1.0, 1.0, 1.0), zoom=1.15)
    triad_ax.view_init(elev=22, azim=-58)
    triad_ax.quiver(0, 0, 0, 1, 0, 0, color="0.2", arrow_length_ratio=0.16)
    triad_ax.quiver(0, 0, 0, 0, 1, 0, color="0.2", arrow_length_ratio=0.16)
    triad_ax.quiver(0, 0, 0, 0, 0, 1, color="0.2", arrow_length_ratio=0.16)
    triad_ax.text(1.12, 0, 0, "$x$", fontsize=6)
    triad_ax.text(0, 1.12, 0, "$y$", fontsize=6)
    triad_ax.text(0, 0, 1.12, "$z$", fontsize=6)

    colorbar_axis = fig.add_axes([0.30, 0.10, 0.49, 0.025])
    colorbar = fig.colorbar(
        cm.ScalarMappable(norm=norm, cmap=cmap),
        cax=colorbar_axis,
        orientation="horizontal",
    )
    colorbar.set_label(
        r"Concentration ($\mu$g m$^{-3}$)", fontsize=5.5, labelpad=1
    )
    colorbar.ax.xaxis.set_label_position("top")
    colorbar.ax.tick_params(labelsize=5, pad=1, length=2)
    output.parent.mkdir(parents=True, exist_ok=True)
    # Use an explicit crop instead of ``tight_layout`` because Matplotlib's 3-D
    # artist bounds contain large transparent margins.
    crop = Bbox.from_bounds(1.00, 0.0, 1.75, 1.22)
    fig.savefig(output, format="pdf", bbox_inches=crop, pad_inches=0)
    plt.close(fig)


def parse_args() -> argparse.Namespace:
    """Parse output, sample-count, and reproducibility options."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("output/pdf/single_gaussian_point_cloud.pdf"),
    )
    parser.add_argument("--points", type=int, default=650)
    parser.add_argument("--seed", type=int, default=17)
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    create_figure(args.output, args.points, args.seed)
