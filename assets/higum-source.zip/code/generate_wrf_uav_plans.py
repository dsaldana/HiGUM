#!/usr/bin/env python3
"""Generate top-view cooperative UAV plans over three HGM levels.

For each level, k-means allocates Gaussian centroids to UAVs, exhaustive search
finds the shortest depot-aware Hamiltonian cycle in each small cluster, and a
constant-speed Ackermann MPC converts the waypoint order into a smooth path.
"""

from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import cm
from matplotlib.colors import LogNorm
from matplotlib.patches import Ellipse
from sklearn.cluster import KMeans

from generate_wrf_hgm_hierarchy import extract_point_cloud, hierarchy
from planner import ackermann_mpc, run_mpc


def node_statistics(
    points: np.ndarray, concentration: np.ndarray, partitions: list[np.ndarray]
) -> list[tuple[np.ndarray, np.ndarray, float]]:
    """Return the mean, covariance, and average PM2.5 value of every node."""
    result = []
    for indices in partitions:
        subset = points[indices]
        # The Gaussian models position; concentration is summarized separately.
        result.append(
            (
                subset.mean(axis=0),
                np.cov(subset, rowvar=False) + np.eye(3) * 1e-6,
                float(concentration[indices].mean()),
            )
        )
    return result


def exact_depot_cycle(waypoints: np.ndarray, depot: np.ndarray) -> np.ndarray:
    """Solve the shortest depot-aware Hamiltonian cycle by enumeration.

    The returned route lists each HGM waypoint once and appends the depot.  The
    initial depot is implicit in the vehicle state.  Exhaustive search is exact
    and practical here because k-means produces small per-UAV waypoint sets.
    """
    if len(waypoints) == 0:
        return depot[None, :]
    best_order: tuple[int, ...] | None = None
    best_length = np.inf
    for order in itertools.permutations(range(len(waypoints))):
        ordered = waypoints[list(order)]
        length = np.linalg.norm(ordered[0] - depot)
        if len(ordered) > 1:
            length += np.linalg.norm(np.diff(ordered, axis=0), axis=1).sum()
        # Close the tour by returning from the last waypoint to the depot.
        length += np.linalg.norm(ordered[-1] - depot)
        if length < best_length:
            best_length = float(length)
            best_order = order
    assert best_order is not None
    return np.vstack([waypoints[list(best_order)], depot])


def allocate_and_order(
    means_xy: np.ndarray, depot: np.ndarray, n_uavs: int, seed: int
) -> list[np.ndarray]:
    """Allocate centroids with k-means and order each cluster by exact TSP."""
    # Multiple initializations reduce sensitivity to a poor k-means start.
    labels = KMeans(
        n_clusters=n_uavs, random_state=seed, n_init=20
    ).fit_predict(means_xy)
    routes = []
    for cluster in range(n_uavs):
        routes.append(exact_depot_cycle(means_xy[labels == cluster], depot))
    return routes


def plan_routes(
    waypoint_routes: list[np.ndarray], depot: np.ndarray
) -> list[np.ndarray]:
    """Track every Hamiltonian cycle with the existing Ackermann MPC."""
    # Match octree2.ipynb after converting its raw-grid plotting coordinates
    # to this figure's kilometer coordinates. The notebook solves after
    # dividing grid coordinates by 100 and plots after multiplying by 100;
    # with 0.1 km per grid cell, its L=0.5 and v0=1 correspond to 5 km and
    # 10 km/model-time-unit here, respectively.
    horizon = 100
    dt = 0.1
    turning_length = 5.0
    speed = 10.0
    solver = ackermann_mpc(
        N=horizon, dt=dt, L=turning_length, v0=speed
    )
    trajectories = []
    for route in waypoint_routes:
        # Orient the fixed-wing model toward its first assigned waypoint.
        first_direction = route[0] - depot
        heading = np.arctan2(first_direction[1], first_direction[0])
        initial_state = np.array([depot[0], depot[1], heading])
        trajectory, reached = run_mpc(
                solver,
                initial_state,
                route,
                N=horizon,
                dt=dt,
                L=turning_length,
                v0=speed,
                delta_max=np.deg2rad(60.0),
                max_iters_per_wp=500,
                # The 60-degree steering bound gives R_min = L/tan(delta_max)
                # = 2.89 km, so use a reachable 3 km waypoint acceptance disk.
                wp_tol=3.0,
                max_steps=5000,
                return_status=True,
                integration_substeps=2,
            )
        if not all(reached):
            missed = [index + 1 for index, success in enumerate(reached) if not success]
            raise RuntimeError(f"MPC failed to reach waypoints {missed} in route {route}")
        trajectories.append(trajectory)
    return trajectories


def draw_ellipse(ax, mean: np.ndarray, covariance: np.ndarray, color) -> None:
    """Draw the horizontal two-standard-deviation projection of a 3-D node."""
    covariance_xy = covariance[:2, :2]
    eigenvalues, eigenvectors = np.linalg.eigh(covariance_xy)
    order = np.argsort(eigenvalues)[::-1]
    eigenvalues = np.maximum(eigenvalues[order], 1e-12)
    eigenvectors = eigenvectors[:, order]
    # Matplotlib expects full diameters.  A two-standard-deviation semi-axis
    # therefore becomes a diameter of 4*sqrt(eigenvalue).
    width, height = 4.0 * np.sqrt(eigenvalues)
    angle = np.degrees(np.arctan2(eigenvectors[1, 0], eigenvectors[0, 0]))
    ax.add_patch(
        Ellipse(
            mean[:2], width, height, angle=angle,
            facecolor=color, edgecolor=color, alpha=0.22, linewidth=0.75,
        )
    )
    ax.scatter(
        mean[0], mean[1], s=10, marker="o", color=color,
        edgecolors="black", linewidths=0.25, zorder=4,
    )


def draw_panel(
    ax, points: np.ndarray, concentration: np.ndarray,
    statistics: list[tuple[np.ndarray, np.ndarray, float]],
    waypoint_routes: list[np.ndarray], trajectories: list[np.ndarray],
    norm: LogNorm, cmap,
) -> None:
    """Draw one top-view panel with HGM nodes, tours, and MPC trajectories."""
    ax.scatter(
        points[:, 0], points[:, 1], c=concentration,
        cmap=cmap, norm=norm, s=1.1, alpha=0.16, linewidths=0,
    )
    for mean, covariance, average in statistics:
        draw_ellipse(ax, mean, covariance, cmap(norm(average)))

    route_colors = (
        "#1565c0", "#00a087", "#7b2cbf", "#e76f00", "#c2185b"
    )
    for uav, (route, trajectory, color) in enumerate(
        zip(waypoint_routes, trajectories, route_colors), start=1
    ):
        # ``route[-1]`` is the depot appended by ``exact_depot_cycle``; prepend
        # it for plotting so the dashed polyline shows the complete closed tour.
        intended_cycle = np.vstack([route[-1], route])
        ax.plot(
            intended_cycle[:, 0], intended_cycle[:, 1], color=color,
            linewidth=0.75, linestyle="--", alpha=0.50, zorder=5,
        )
        ax.plot(
            trajectory[:, 0], trajectory[:, 1], color=color,
            linewidth=1.35, linestyle="-", alpha=0.95,
            label=f"UAV {uav}", zorder=6,
        )
        ax.scatter(
            route[:-1, 0], route[:-1, 1], s=13, marker="x",
            color=color, linewidths=0.9, zorder=7,
        )
    depot = waypoint_routes[0][-1]
    ax.scatter(
        depot[0], depot[1], marker="*", s=38, color="black",
        label="Depot", zorder=8,
    )

    plotted_xy = np.vstack([points[:, :2], *[traj[:, :2] for traj in trajectories]])
    padding = np.array([0.8, 0.8])
    ax.set_xlim(
        plotted_xy[:, 0].min() - padding[0], plotted_xy[:, 0].max() + padding[0]
    )
    ax.set_ylim(
        plotted_xy[:, 1].min() - padding[1], plotted_xy[:, 1].max() + padding[1]
    )
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel(r"$x$ (km)", fontsize=6.5)
    ax.set_ylabel(r"$y$ (km)", fontsize=6.5)
    ax.tick_params(labelsize=5.5, length=2)
    ax.grid(True, color="0.82", linewidth=0.35)


def create_figure(smoke_path: Path, output: Path, seed: int) -> None:
    """Build all planning cases and export the vertical three-panel figure."""
    points, concentration = extract_point_cloud(smoke_path)
    levels = hierarchy(points, seed)
    norm = LogNorm(vmin=concentration.min(), vmax=concentration.max())
    cmap = plt.get_cmap("inferno")
    depot = np.array([8.0, 20.0])

    plt.rcParams.update({"font.family": "serif", "font.size": 7})
    fig, axes = plt.subplots(3, 1, figsize=(3.45, 7.75))
    # Tuple entries are: number of HGM leaves, number of UAVs, panel title.
    panels = (
        (8, 3, "(a) HGM level 3: 8 ellipsoids, 3 UAVs"),
        (16, 3, "(b) HGM level 4: 16 ellipsoids, 3 UAVs"),
        (32, 5, "(c) HGM level 5: 32 ellipsoids, 5 UAVs"),
    )
    for ax, (count, n_uavs, title) in zip(axes, panels):
        statistics = node_statistics(points, concentration, levels[count])
        means_xy = np.array([item[0][:2] for item in statistics])
        waypoint_routes = allocate_and_order(means_xy, depot, n_uavs, seed)
        trajectories = plan_routes(waypoint_routes, depot)
        draw_panel(
            ax, points, concentration, statistics,
            waypoint_routes, trajectories, norm, cmap,
        )
        if ax is not axes[-1]:
            ax.set_xlabel("")
        ax.set_title(title, fontsize=7.5, pad=3)

    handles, labels = axes[-1].get_legend_handles_labels()
    fig.legend(
        handles, labels, loc="lower center", ncol=6,
        bbox_to_anchor=(0.5, 0.002), frameon=False, fontsize=5.2,
    )
    colorbar_axis = fig.add_axes([0.16, 0.047, 0.68, 0.008])
    colorbar = fig.colorbar(
        cm.ScalarMappable(norm=norm, cmap=cmap),
        cax=colorbar_axis, orientation="horizontal",
    )
    colorbar.set_label(
        r"WRF-FIRE PM$_{2.5}$ concentration ($\mu$g m$^{-3}$)",
        fontsize=6.3, labelpad=1,
    )
    colorbar.ax.xaxis.set_label_position("top")
    colorbar.ax.tick_params(labelsize=5.2, pad=1, length=2)
    fig.subplots_adjust(left=0.15, right=0.97, top=0.98, bottom=0.105, hspace=0.17)

    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, format="pdf", bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)


def parse_args() -> argparse.Namespace:
    """Parse WRF-FIRE input, output, and deterministic random seed."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--smoke", type=Path, default=Path("code/fire_smoke_data.npy"))
    parser.add_argument(
        "--output", type=Path,
        default=Path("output/pdf/wrf_fire_uav_plans.pdf"),
    )
    parser.add_argument("--seed", type=int, default=0)
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    create_figure(args.smoke, args.output, args.seed)
