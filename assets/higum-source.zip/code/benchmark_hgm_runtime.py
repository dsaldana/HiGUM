#!/usr/bin/env python3
"""Benchmark cumulative HGM construction time and plot it by tree level.

The benchmark uses every valid WRF-FIRE voxel rather than the visualization
subsample.  The input and random seeds are deterministic; elapsed wall-clock
time can nevertheless vary with the machine and operating-system load.
"""

from __future__ import annotations

import argparse
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from sklearn.mixture import GaussianMixture

from generate_wrf_hgm_hierarchy import extract_point_cloud


def split_splittable_nodes(
    points: np.ndarray, partitions: list[np.ndarray], seed: int
) -> list[np.ndarray]:
    """Split non-singleton nodes and retain singleton terminal leaves."""
    children: list[np.ndarray] = []
    for number, indices in enumerate(partitions):
        # A binary GMM cannot be estimated from one sample.  Preserve such a
        # node as a terminal leaf while other branches continue to refine.
        if len(indices) < 2:
            children.append(indices)
            continue
        model = GaussianMixture(
            n_components=2,
            covariance_type="full",
            reg_covar=1e-6,
            random_state=seed + number,
        )
        labels = model.fit_predict(points[indices])
        node_children = [indices[labels == component] for component in range(2)]
        children.extend(child for child in node_children if len(child) > 0)
    return children


def benchmark(
    points: np.ndarray, max_level: int, repeats: int, seed: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return cumulative wall-clock times and node counts for every level."""
    measurements = np.empty((repeats, max_level), dtype=float)
    node_counts = np.empty((repeats, max_level), dtype=int)
    root = np.arange(len(points))
    for repetition in range(repeats):
        # Restart at the root so each repetition measures the same work.
        partitions = [root]
        start = time.perf_counter()
        for level in range(1, max_level + 1):
            partitions = split_splittable_nodes(points, partitions, seed)
            measurements[repetition, level - 1] = time.perf_counter() - start
            node_counts[repetition, level - 1] = len(partitions)
    return measurements, node_counts


def create_figure(
    smoke_path: Path, output: Path, max_level: int, repeats: int, seed: int
) -> None:
    """Run the benchmark, save its mean-time plot, and print raw summaries."""
    # Use every valid voxel. The every-50th-point visualization subset contains
    # singleton nodes at depth 9. At deeper levels these are retained as
    # terminal leaves because a two-component GMM requires at least two points.
    points, _ = extract_point_cloud(smoke_path, skip=1)
    timings, node_counts = benchmark(points, max_level, repeats, seed)
    levels = np.arange(1, max_level + 1)
    # Plot only the mean because this experiment uses a deterministic dataset;
    # repeated measurements quantify runtime, not data uncertainty.
    mean = timings.mean(axis=0)

    plt.rcParams.update({"font.family": "serif", "font.size": 7})
    fig, ax = plt.subplots(figsize=(3.45, 2.35))
    ax.plot(levels, mean, color="#1565c0", marker="o", markersize=3.2,
            linewidth=1.3)
    ax.set_xlim(0.7, max_level + 0.3)
    ax.set_ylim(bottom=0)
    ax.set_xticks(levels)
    ax.set_xlabel("HGM level")
    ax.set_ylabel("Cumulative running time (s)")
    ax.grid(True, color="0.84", linewidth=0.45)
    fig.tight_layout(pad=0.35)

    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, format="pdf", bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)

    print(f"points={len(points)}, repeats={repeats}")
    for level, average, count in zip(levels, mean, node_counts[0]):
        print(
            f"level={level:2d}, nodes={count:6d}, "
            f"mean={average:.6f}s"
        )


def parse_args() -> argparse.Namespace:
    """Parse benchmark depth, repetitions, paths, and random seed."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--smoke", type=Path, default=Path("code/fire_smoke_data.npy"))
    parser.add_argument(
        "--output", type=Path,
        default=Path("output/pdf/hgm_runtime_levels.pdf"),
    )
    parser.add_argument("--max-level", type=int, default=15)
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--seed", type=int, default=0)
    return parser.parse_args()


if __name__ == "__main__":
    arguments = parse_args()
    create_figure(
        arguments.smoke, arguments.output, arguments.max_level,
        arguments.repeats, arguments.seed,
    )
