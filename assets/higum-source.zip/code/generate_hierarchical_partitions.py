#!/usr/bin/env python3
"""Generate the synthetic-plume binary GMM hierarchy figure.

Each node is divided using a two-component, full-covariance Gaussian mixture
model.  Partitions contain indices into the original arrays, which keeps point
positions and scalar concentrations aligned without copying either dataset.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import cm
from matplotlib.colors import Normalize
from matplotlib.transforms import Bbox
from sklearn.mixture import GaussianMixture

from generate_single_ellipsoid import (
    ellipsoid_wireframe,
    generate_point_cloud,
)


def split_once(
    points: np.ndarray,
    partitions: list[np.ndarray],
    seed: int,
) -> list[np.ndarray]:
    """Split every current partition into two spatial GMM components.

    Concentration is deliberately excluded from the GMM: it is a value attached
    to a point, whereas the Gaussian describes the distribution of positions.
    """
    children: list[np.ndarray] = []
    for partition_number, indices in enumerate(partitions):
        gmm = GaussianMixture(
            n_components=2,
            covariance_type="full",
            reg_covar=1e-6,
            random_state=seed + partition_number,
        )
        # EM estimates the component parameters and the maximum-responsibility
        # label converts the soft GMM into disjoint child datasets.
        labels = gmm.fit_predict(points[indices])
        children.extend([indices[labels == child] for child in range(2)])
    return children


def hierarchy_levels(
    points: np.ndarray, seed: int
) -> dict[int, list[np.ndarray]]:
    """Return binary hierarchy levels containing 2, 4, 8, and 16 leaves."""
    partitions = [np.arange(len(points))]
    levels: dict[int, list[np.ndarray]] = {}
    # Four binary refinements produce 2, 4, 8, and 16 leaves.
    for _ in range(4):
        partitions = split_once(points, partitions, seed)
        levels[len(partitions)] = partitions
    return levels


def draw_level(
    ax,
    points: np.ndarray,
    concentration: np.ndarray,
    partitions: list[np.ndarray],
    norm: Normalize,
    cmap,
    title: str,
) -> None:
    """Draw one hierarchy level with one ellipsoid per partition."""
    ax.scatter(
        points[:, 0],
        points[:, 1],
        points[:, 2],
        c=concentration,
        cmap=cmap,
        norm=norm,
        s=3.5,
        alpha=0.42,
        linewidths=0,
        depthshade=False,
    )

    for indices in partitions:
        partition_points = points[indices]
        mean = partition_points.mean(axis=0)
        covariance = np.cov(partition_points, rowvar=False)
        # The node's representative measurement is an ordinary arithmetic mean.
        average = concentration[indices].mean()
        x_ell, y_ell, z_ell = ellipsoid_wireframe(
            mean, covariance, n_std=2.0, n_azimuth=36, n_polar=18
        )
        color = cmap(norm(average))
        ax.plot_wireframe(
            x_ell,
            y_ell,
            z_ell,
            rstride=2,
            cstride=2,
            color=color,
            linewidth=0.55,
            alpha=0.9,
        )
        ax.scatter(*mean, color=color, marker="x", s=13, linewidth=0.8)

    point_min = points.min(axis=0)
    point_max = points.max(axis=0)
    padding = 0.04 * (point_max - point_min)
    ax.set_xlim(point_min[0] - padding[0], point_max[0] + padding[0])
    ax.set_ylim(point_min[1] - padding[1], point_max[1] + padding[1])
    ax.set_zlim(point_min[2] - padding[2], point_max[2] + padding[2])
    ax.set_box_aspect(np.ptp(points, axis=0), zoom=1.30)
    ax.view_init(elev=22, azim=-58)
    ax.set_axis_off()


def create_figure(output: Path, n_points: int, seed: int) -> None:
    """Generate and save the three-panel hierarchy illustration."""
    points, concentration = generate_point_cloud(n_points, seed)
    levels = hierarchy_levels(points, seed)
    norm = Normalize(concentration.min(), concentration.max())
    cmap = plt.get_cmap("inferno")

    plt.rcParams.update({"font.family": "serif", "font.size": 7})
    fig = plt.figure(figsize=(3.45, 1.38))
    panel_titles = {
        2: "(a) 2 partitions",
        4: "(b) 4 partitions",
        8: "(c) 8 partitions",
    }
    panel_positions = (
        [-0.005, 0.02, 0.34, 0.92],
        [0.330, 0.02, 0.34, 0.92],
        [0.665, 0.02, 0.34, 0.92],
    )
    for count, position in zip((2, 4, 8), panel_positions):
        ax = fig.add_axes(position, projection="3d")
        draw_level(
            ax,
            points,
            concentration,
            levels[count],
            norm,
            cmap,
            panel_titles[count],
        )
    for x_position, count in zip((0.165, 0.500, 0.835), (2, 4, 8)):
        fig.text(
            x_position,
            0.75,
            panel_titles[count],
            ha="center",
            va="top",
            fontsize=6.5,
        )

    colorbar_axis = fig.add_axes([0.08, 0.14, 0.84, 0.025])
    colorbar = fig.colorbar(
        cm.ScalarMappable(norm=norm, cmap=cmap),
        cax=colorbar_axis,
        orientation="horizontal",
    )
    colorbar.set_label(
        r"Concentration ($\mu$g m$^{-3}$)", fontsize=5.5, labelpad=1
    )
    colorbar.ax.xaxis.set_label_position("top")
    colorbar.ax.tick_params(labelsize=5, pad=1, length=2)

    output.parent.mkdir(parents=True, exist_ok=True)
    crop = Bbox.from_bounds(0.12, 0.0, 3.33, 1.12)
    fig.savefig(output, format="pdf", bbox_inches=crop, pad_inches=0)
    plt.close(fig)


def parse_args() -> argparse.Namespace:
    """Parse output, sample-count, and reproducibility options."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("output/pdf/hierarchical_gmm_partitions.pdf"),
    )
    parser.add_argument("--points", type=int, default=650)
    parser.add_argument("--seed", type=int, default=17)
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    create_figure(args.output, args.points, args.seed)
