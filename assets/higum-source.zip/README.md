# HiGUM source bundle

Original paper methods are in code/. The Manim presentation is in slides/.
See the README in each directory for requirements and execution instructions.
The included precomputed NPZ bundles are enough to render the slides.
The original large WRF-FIRE input arrays are not bundled; rebuilding from raw
simulation data requires code/fire_smoke_data.npy as described in code/README.md.
The manuscript is distributed separately as paper.pdf on the project website.
